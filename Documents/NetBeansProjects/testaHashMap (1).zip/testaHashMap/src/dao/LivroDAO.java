package dao;

import java.beans.XMLDecoder;
import java.beans.XMLEncoder;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.HashMap;
import modelo.Livro;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author friend
 */
public class LivroDAO {
    
     public void saveAllCarros(HashMap<String, Livro> livros) {
        FileOutputStream fout = null;
        try {
            fout = new FileOutputStream("/home/friend/livros.xml");
            BufferedOutputStream bos = new BufferedOutputStream(fout);
            XMLEncoder xmlEncoder = new XMLEncoder(bos);
            xmlEncoder.writeObject(livros);
            xmlEncoder.close();
        } catch (Exception ex) {
            System.out.println("Erro: " + ex.getMessage());
        }
    }

    public HashMap<String, Livro> loadAll() {
        HashMap<String, Livro> livros = new HashMap();
        try {
            FileInputStream fis = new FileInputStream("/home/friend/livros.xml");
            BufferedInputStream bis = new BufferedInputStream(fis);
            XMLDecoder xmlDecoder = new XMLDecoder(bis);
            livros = (HashMap<String, Livro>) xmlDecoder.readObject();
        } catch (Exception e) {
            System.out.println("erro ao ler");
        } 
        return livros;
    }
    
    public static void main(String[] args) {
        
        // criando alguns livros        
        HashMap<String, Livro> livros = new HashMap();
        livros.put("123", new Livro("123", "Java 1"));
        livros.put("456", new Livro("456", "Java 2"));
        livros.put("789", new Livro("789", "Java 3"));
        
        // gravando os livros
        LivroDAO ldao = new LivroDAO();
        ldao.saveAllCarros(livros);  
        
        // lendo os livros
        HashMap<String, Livro> livros2 = ldao.loadAll();
        
        // encontrando o livro de codigo de barras igual a 123
        String codigoBusca = "456";
        Livro busca =new Livro("vazio","vazio");
        if (livros2.containsKey(codigoBusca)){
            busca = livros2.get(codigoBusca);
        }
        
        // mostrando os dados do livro
        System.out.println("Livro de codigo "+codigoBusca+"  = "+ busca.getTitulo());        
    }    
}
