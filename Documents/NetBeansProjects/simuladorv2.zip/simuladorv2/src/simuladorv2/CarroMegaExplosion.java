package simuladorv2;

public class CarroMegaExplosion extends Carro {
    
    public CarroMegaExplosion(String id, float rendimento, 
            float capacidadeTanque, int zeroACem, int velocidadeMaxima) {
        super(id, rendimento, capacidadeTanque, zeroACem, velocidadeMaxima);
        
        // esse carro vai comecar na velocidade maxima
        this.setEstado("andando");
        this.setVelocidadeAtual(velocidadeMaxima);        
    }
}
