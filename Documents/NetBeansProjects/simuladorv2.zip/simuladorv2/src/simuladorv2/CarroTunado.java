package simuladorv2;

public class CarroTunado extends Carro implements Aerofolio, SprintBooster{

    private double speedImprovement;
    
    private double boostFactor;
    
    public CarroTunado(String id, double rendimento, double capacidadeTanque, 
            int zeroACem, int velocidadeMaxima, double speedImprovement, 
            double boostFactor) {
        super(id, rendimento, capacidadeTanque, zeroACem, velocidadeMaxima);
        this.setSpeedImprovement(speedImprovement);
        this.setBoostFactor(boostFactor);
    }

    // ** implementacoes da interface Aerofolio
    
    // sobreescreve o rendimento do carro tunado com aerofolio
    public double getRendimento() {
        System.out.println("rendimento incrementado pelo aerofolio!");
        return super.getRendimento() * this.getSpeedImprovement();
    }

    public double getSpeedImprovement() {
        return speedImprovement;
    }

    public void setSpeedImprovement(double speedImprovement) {
        this.speedImprovement = speedImprovement;
    }
    
    // ** implementacoes da interface SprintBooster
    
    public double getBoostFactor() {
        return boostFactor;
    }

    public void setBoostFactor(double boostFactor) {
        this.boostFactor = boostFactor;
    }

    // sobreescreve a velocidade maxima com o sprinterBoost
    public int getVelocidadeMaxima() {
        System.out.println("boost na velocidade maxima!");
        return (int) (super.getVelocidadeMaxima() * this.getBoostFactor());
    }
    
}