package simuladorv2;

public interface Aerofolio {
    
    public void setSpeedImprovement(double speedImprovement);
    public double getSpeedImprovement();
    
    // o aerofolio vai alterar o carro atualizando o rendimento
    public double getRendimento();
    
}
