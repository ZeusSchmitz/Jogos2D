package simuladorv2;

public class Pista {
    private float extensao;

    public Pista(float extensao) {
        this.extensao = extensao;
    }
    
    public float getExtensao() {
        return extensao;
    }

    public void setExtensao(float extensao) {
        this.extensao = extensao;
    }
}
