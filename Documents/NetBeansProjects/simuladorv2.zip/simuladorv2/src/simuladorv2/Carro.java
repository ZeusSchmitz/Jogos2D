package simuladorv2;

public class Carro {

    private String id; // um identificador para o carro
    private double rendimento;
    private double capacidadeTanque;
    private int zeroACem;
    private int velocidadeMaxima;

    // metodos internos para controle do carro
    private String estado; // parado, andando, abastecendo
    private double velocidadeAtual; // ponteiro do velocimetro
    private double hodometro; // acumulador de km percorridos
    private double ponteiroDoCombustivel; // medidor de combustivel restante

    public Carro(String id, double rendimento, double capacidadeTanque, 
            int zeroACem, int velocidadeMaxima) {
        this.id = id;
        this.rendimento = rendimento;
        this.capacidadeTanque = capacidadeTanque;
        this.zeroACem = zeroACem;
        this.velocidadeMaxima = velocidadeMaxima;

        // o carro vai comecar acelerando?
        this.estado = "parado";
        this.velocidadeAtual = 0;
        this.hodometro = 0;

        // o carro sai da fabrica com tanque cheio :-)
        this.ponteiroDoCombustivel = this.capacidadeTanque;
    }

    public double getRendimento() {
        return rendimento;
    }

    public void setRendimento(double rendimento) {
        this.rendimento = rendimento;
    }

    public double getCapacidadeTanque() {
        return capacidadeTanque;
    }

    public void setCapacidadeTanque(double capacidadeTanque) {
        this.capacidadeTanque = capacidadeTanque;
    }

    public int getZeroACem() {
        return zeroACem;
    }

    public void setZeroACem(int zeroACem) {
        this.zeroACem = zeroACem;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public int getVelocidadeMaxima() {
        return velocidadeMaxima;
    }

    public void setVelocidadeMaxima(int velocidadeMaxima) {
        this.velocidadeMaxima = velocidadeMaxima;
    }

    public double getHodometro() {
        return hodometro;
    }

    public void setHodometro(double hodometro) {
        this.hodometro = hodometro;
    }

    public double getPonteiroDoCombustivel() {
        return ponteiroDoCombustivel;
    }

    public void setPonteiroDoCombustivel(double ponteiroDoCombustivel) {
        this.ponteiroDoCombustivel = ponteiroDoCombustivel;
    }

    public double getVelocidadeAtual() {
        return velocidadeAtual;
    }

    public void setVelocidadeAtual(double velocidadeAtual) {
        this.velocidadeAtual = velocidadeAtual;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    // retorna o incremento de velocidade que o carro deve realizar
    public double acelere() {
        return (this.getVelocidadeMaxima() * this.zeroACem) / 100;
    }

    public boolean alcancouVelocidadeMaxima() {
        return this.velocidadeAtual >= this.getVelocidadeMaxima();
    }

    //
    // ********* metodos especiais
    //
    
    public void ande() {
        // quantos km eh possivel andar
        double deslocamento = this.getVelocidadeAtual() / 3600;

        // ANDE! Incremente o hodometro
        this.hodometro += deslocamento;

        // tire do tanque o combustivel gasto pra andar
        this.ponteiroDoCombustivel -= deslocamento / this.getRendimento();
        // PERGUNTA: porque nessa linha acima deve-se usar getRendimento
        // e NÃO rendimento?
    }

    public void pulso() {
        // se o carro estah parado
        if (this.estado.equals("parado")) {

            // faça a primeira aceleracao
            this.velocidadeAtual = this.acelere();

            // ANDE!
            this.ande();

            // agora o carro estah andando!
            this.estado = "acelerando";
        } else if (this.estado.equals("acelerando")) {
            // aumente a velocidade
            this.velocidadeAtual += this.acelere();
            // ANDE!
            this.ande();
            // verifique se jah atingiu velocidade maxima
            if (this.alcancouVelocidadeMaxima()) {
                this.estado = "andando";
            }
        } else if (this.estado.equals("andando")) {
          this.ande();
        } else if (this.estado.equals("freiando")) {
            // reduza a velocidade (na mesma proporção da aceleracao)
            this.velocidadeAtual -= this.acelere(); //MELHORAR nome "acelere"
            if (this.velocidadeAtual <= 0) {
                this.velocidadeAtual = 0;
                this.estado = "parado";
            }
        }
    }
}
