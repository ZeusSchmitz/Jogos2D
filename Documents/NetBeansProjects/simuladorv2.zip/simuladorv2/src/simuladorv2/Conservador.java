package simuladorv2;

public class Conservador extends Piloto {
    
    public void pulso() {
        
        // o piloto estah em um carro?
        if (this.getCarro() != null) {
            
            // o piloto estah dirigindo em uma pista?
            if (this.getPista() != null) {
                
                //verifica se ainda nao chegou ao fim da pista
                if (this.lookHodometro() < this.getPista().getExtensao()) {
                  // faz o carro andar
                  this.getCarro().pulso();
                } else {  
                  // se ultrapassou a extensao da pista, inicia a frenagem
                  this.getCarro().setEstado("freiando");
                } 
            }
            
            // esse perfil sempre dah um pulso no carro
            this.getCarro().pulso();
        }
    }       
}
