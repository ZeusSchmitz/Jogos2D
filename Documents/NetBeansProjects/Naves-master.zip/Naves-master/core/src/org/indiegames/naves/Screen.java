package org.indiegames.naves;

public interface Screen {
    void update(double step);
    void render(double delta);
}
