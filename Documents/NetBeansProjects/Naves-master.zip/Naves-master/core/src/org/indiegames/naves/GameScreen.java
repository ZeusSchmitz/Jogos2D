package org.indiegames.naves;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.assets.AssetManager;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

import java.util.ArrayList;
import java.util.List;

public class GameScreen implements Screen {

    private final AssetManager assetManager;
    private final List<Entity> entities =
            new ArrayList<>();

    private SpriteBatch batch = new SpriteBatch();

    public GameScreen(AssetManager assetManager) {
        this.assetManager = assetManager;
    }

    @Override
    public void update(double step) {
        if (random() > 8) {
            Entity entity = new Entity();
            entity.setX((int) (60 * random()));
            entity.setY(Gdx.graphics.getHeight());
            entity.setHeight((int) (100 * random()));
            entity.setWidth((int) (100 * random()));
            entity.setTexture(assetManager.get("assets/estrela.png", Texture.class));
            entities.add(entity);
        }

        for(Entity entity : entities) {
            entity.setY(entity.getY() - 1);
        }
    }

    @Override
    public void render(double delta) {
        Gdx.gl.glClearColor(0f, 0f, 0f, 0f);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        batch.begin();
        for(Entity entity : entities) {
            batch.draw(entity.getTexture(),
                    entity.getX(), entity.getY(),
                    entity.getWidth(), entity.getHeight());
        }
        batch.end();
    }

    private double random() {
        return (Math.random() * 10) % 10;
    }
}

