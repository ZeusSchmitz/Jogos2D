package org.indiegames.naves;

import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.BitmapFont;

public class FontManager {
    private static BitmapFont defaultGreenFont;
    private static BitmapFont defaultRedFont;
    private static BitmapFont defaultYellowFont;
    private static BitmapFont defaultFont;

    public static BitmapFont createFont(Color color) {
        BitmapFont font = new BitmapFont();
        font.setColor(color);
        return font;
    }

    public static BitmapFont getDefaultGreenFont() {
        if (defaultGreenFont == null) {
           defaultGreenFont = createFont(Color.GREEN);
        }
        return defaultGreenFont;
    }

    public static BitmapFont getDefaultRedFont() {
        if (defaultRedFont == null) {
           defaultRedFont = createFont(Color.RED);
        }
        return defaultRedFont;
    }

    public static BitmapFont getDefaultYellowFont() {
        if (defaultYellowFont == null) {
           defaultYellowFont = createFont(Color.YELLOW);
        }
        return defaultYellowFont;
    }

    public static BitmapFont getDefaultFont() {
        if (defaultFont == null) {
            defaultFont = createFont(Color.WHITE);
        }
        return defaultFont;
    }
}
