package org.indiegames.naves;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.assets.AssetManager;
import com.badlogic.gdx.utils.TimeUtils;

public class Game extends ApplicationAdapter {
    private AssetManager assetManager;
    private FpsOverlay fpsOverlay;
    private Screen screen;

    private double currentTime;
    private double accumulator;
    private float step = 1.0f / 60.0f;

    @Override
    public void create() {
        super.create();
        this.assetManager = new AssetManager();
        this.screen = new LoadingScreen(assetManager, this);
        this.fpsOverlay = new FpsOverlay();
    }

    /**
     * Separa a l�gica do jogo da renderiza��o
     */
    @Override
    public void render() {
        double newTime = TimeUtils.millis() / 1000.0;
        double realFrameTime = newTime - currentTime;
        double frameTime = Math.min(realFrameTime, 0.25);

        currentTime = newTime;
        accumulator += frameTime;

        while (accumulator >= step) {
            accumulator -= step;
            screen.update(step);
        }

        screen.render(accumulator / step);
        fpsOverlay.render(1.0f / realFrameTime);
    }

    public void setScreen(GameScreen screen) {
        this.screen = screen;
    }
}
