package org.indiegames.naves;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.GlyphLayout;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public class FpsOverlay {

    private SpriteBatch batch = new SpriteBatch();
    private GlyphLayout glyph = new GlyphLayout();

    public void render(double fps) {
        BitmapFont font = FontManager.getDefaultRedFont();

        if (fps > 40) {
            font = FontManager.getDefaultGreenFont();
        } else {
            if (fps > 20) {
                font = FontManager.getDefaultYellowFont();
            }
        }

        String message = String.format("FPS: %.0f", fps);
        glyph.setText(font, message);
        int x = Gdx.graphics.getWidth() - (int)glyph.width - 10;
        int y = Gdx.graphics.getHeight() - 10;
        batch.begin();
        font.draw(batch, message, x, y);
        batch.end();
    }
}
