package org.indiegames.naves;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.assets.AssetManager;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.GlyphLayout;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public class LoadingScreen implements Screen {
    private final SpriteBatch spriteBatch = new SpriteBatch();
    private final GlyphLayout glyphLayout = new GlyphLayout();
    private final AssetManager assetManager;
    private final Game game;
    private float progress = 0;

    public LoadingScreen(AssetManager assetManager, Game game) {
        this.assetManager = assetManager;
        this.game = game;
        assetManager.load("assets/estrela.png", Texture.class);
    }

    @Override
    public void update(double step) {
        if(assetManager.update()) {
            game.setScreen(new GameScreen(assetManager));
        }
        this.progress = assetManager.getProgress();
    }

    @Override
    public void render(double delta) {
        Gdx.gl.glClearColor(0f, 0f, 0f, 0f);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        String message = "Carregando...";
        BitmapFont font = FontManager.getDefaultYellowFont();
        glyphLayout.setText(font, message);

        int x = (Gdx.graphics.getWidth() / 2) - ((int)glyphLayout.width / 2);
        int y = (Gdx.graphics.getHeight() / 2);

        spriteBatch.begin();
        font.draw(spriteBatch, message, x, y);
        spriteBatch.end();
    }
}
