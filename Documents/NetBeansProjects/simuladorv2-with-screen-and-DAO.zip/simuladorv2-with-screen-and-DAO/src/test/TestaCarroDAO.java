package test;

import dao.CarroDAO;
import dao.CarroDAO2;
import java.util.ArrayList;
import model.Carro;

public class TestaCarroDAO {
    
    public void testaEscrita() {
        ArrayList<Carro> carros = new ArrayList();
        carros.add(new Carro("A,10, 10, 10, 100"));
        carros.add(new Carro("B,10, 10, 10, 120"));
        carros.add(new Carro("C,10, 10, 12, 100"));
        CarroDAO2 carroDAO = new CarroDAO2();
        //CarroDAO carroDAO = new CarroDAO();
        carroDAO.saveAllCarros(carros);
    }
    
    public void testaLeitura() {
        CarroDAO2 carroDAO = new CarroDAO2();
        //CarroDAO carroDAO = new CarroDAO();
        ArrayList<Carro> carros = carroDAO.loadAllCarros();
        for (Carro carro: carros) {
            System.out.println(carro.getAsCSVLine());
        }
    }    
    
    public static void main(String[] args) {
        
        TestaCarroDAO teste = new TestaCarroDAO();
        teste.testaLeitura();
        //teste.testaEscrita();
    }
}
