package test;

import model.Carro;
import model.Conservador;
import model.Pista;

public class TestaConservador {

    //
    // ********* teste do piloto
    //
    public static void main(String[] args) {

        /*
        
        // testa o piloto SEM usar pista
        
        Carro c1 = new Carro("A", 10, 50, 10, 36);
        Carro c2 = new CarroMegaTurbo("M", 10, 50, 10, 36);
        
        Conservador p1 = new Conservador();
        p1.setCarro(c1);
        
        Conservador p2 = new Conservador();
        p2.setCarro(c2);
                
        for (int i = 0; i < 15; i++) {
            p1.pulso();
            p2.pulso();
            System.out.print(p1.getCarro().getId()+", V= "+
        p1.lookVelocimetro()+", h="+p1.lookHodometro()+" | ");
            System.out.println(p2.getCarro().getId()+", Velocidade: "+
        p2.lookVelocimetro()+", hodometro="+p2.lookHodometro());
        }
        
         */
        // testa o piloto usando a pista
        Conservador p1 = new Conservador();
        //CarroTunado c1 = new CarroTunado("A", 10, 50, 10, 360, 1.1, 1.4);
        //Carro c1 = new Carro("A", 10, 50, 10, 360);
        Carro c1 = new Carro("A, 10, 50, 10, 360");

        //p1.setCarro(new Carro("A", 10, 50, 10, 360));
        p1.setCarro(c1);
        p1.setPista(new Pista(5));

        for (int i = 0; i < 60 * 2; i++) {
            p1.pulso();
            System.out.println(i + ") " + p1.getCarro().getId() + ", V= "
                    + p1.lookVelocimetro() + ", h=" + p1.lookHodometro() 
                    + ", estado=" + p1.getCarro().getEstado() + " | ");
        }
    }
}
