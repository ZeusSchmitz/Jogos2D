package model;

public interface SprintBooster {
    
    public double getBoostFactor();
    public void setBoostFactor(double boostFactor);
    
    // o boost vai alterar o carro atualizando a velocidade maxima em 1 ciclo
    public int getVelocidadeMaxima();
    
}
