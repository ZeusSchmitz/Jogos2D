package model;

public class Pista {
    private double extensao;

    public Pista(double extensao) {
        this.extensao = extensao;
    }
    
    public double getExtensao() {
        return extensao;
    }

    public void setExtensao(double extensao) {
        this.extensao = extensao;
    }
}
