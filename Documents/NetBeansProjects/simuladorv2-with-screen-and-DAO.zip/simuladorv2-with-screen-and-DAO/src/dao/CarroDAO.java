package dao;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

import model.Carro;

public class CarroDAO {

    public void saveAllCarros(ArrayList<Carro> carros) {
        FileOutputStream fout = null;
        try {
            fout = new FileOutputStream("/home/friend/carros.ser");

            ObjectOutputStream oos = new ObjectOutputStream(fout);
            oos.writeObject(carros);
        } catch (Exception ex) {
            System.out.println("Erro: " + ex.getMessage());
        }
    }

    public ArrayList<Carro> loadAllCarros() {
        ObjectInputStream ios = null;
        ArrayList<Carro> carros = new ArrayList();
        try {
            ios = new ObjectInputStream(new 
        FileInputStream("/home/friend/carros.ser"));
            while ((carros = (ArrayList<Carro>) ios.readObject()) != null) {
                System.out.println("lendo dados...");
            }
        } catch (Exception e) {

            System.out.println("erro ao ler");
        } finally {
            try {
                ios.close();
            } catch (Exception ex) {
                System.out.println("nao consegui fechar");
            }
        }
        return carros;
    }

    public ArrayList<Carro> loadAllCarros2() {
        ObjectInputStream objectinputstream = null;
        ArrayList<Carro> carros = new ArrayList();
        try {
            FileInputStream streamIn = new 
        FileInputStream("/home/friend/carros.ser");
            objectinputstream = new ObjectInputStream(streamIn);
             carros = (ArrayList<Carro>) objectinputstream.readObject();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (objectinputstream != null) {
                try {
                    objectinputstream.close();
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }
            return carros;
        }
    }
}
