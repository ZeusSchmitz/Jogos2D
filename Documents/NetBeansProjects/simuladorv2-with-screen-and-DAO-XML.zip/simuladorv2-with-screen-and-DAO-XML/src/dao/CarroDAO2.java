package dao;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

import model.Carro;

public class CarroDAO2 {

    public void saveAllCarros(ArrayList<Carro> carros) {
        try {
            PrintWriter writer = new 
        PrintWriter("/home/friend/carros.csv", "UTF-8");
            for (Carro carro: carros) {
                writer.println(carro.getAsCSVLine());
            }
            writer.close();
        } catch (IOException e) {
            // do something
        }
    }

    public ArrayList<Carro> loadAllCarros() {
        ArrayList<Carro> carros = new ArrayList();

        try {
            Scanner arq;
            arq = new Scanner(new File("/home/friend/carros.csv"));

            while (arq.hasNextLine()) {
                String linha = arq.nextLine();
                Carro c = new Carro(linha);
                carros.add(c);
            }
        } catch (Exception ex) {
            System.out.println("erro ao ler dados: " + ex.getMessage());
        }
        return carros;
    }
}
