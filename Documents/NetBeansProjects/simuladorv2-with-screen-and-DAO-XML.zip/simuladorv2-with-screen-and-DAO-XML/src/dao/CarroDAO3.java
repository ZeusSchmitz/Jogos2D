package dao;

import java.beans.XMLDecoder;
import java.beans.XMLEncoder;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;

import model.Carro;

public class CarroDAO3 {

    // EH PRECISO CRIAR UM CONSTRUTOR Carro()
    // PRA CONFIGURAR A CLASSE Carro COMO SENDO UM JAVABEAN
    
    public void saveAllCarros(ArrayList<Carro> carros) {
        FileOutputStream fout = null;
        try {
            fout = new FileOutputStream("/home/friend/carros.xml");
            BufferedOutputStream bos = new BufferedOutputStream(fout);
            XMLEncoder xmlEncoder = new XMLEncoder(bos);
            xmlEncoder.writeObject(carros);
            xmlEncoder.close();
        } catch (Exception ex) {
            System.out.println("Erro: " + ex.getMessage());
        }
    }

    public ArrayList<Carro> loadAllCarros() {
        ArrayList<Carro> carros = new ArrayList();
        try {
            FileInputStream fis = new FileInputStream("/home/friend/carros.xml");
            BufferedInputStream bis = new BufferedInputStream(fis);
            XMLDecoder xmlDecoder = new XMLDecoder(bis);
            carros = (ArrayList<Carro>) xmlDecoder.readObject();
        } catch (Exception e) {
            System.out.println("erro ao ler");
        } 
        return carros;
    }
}
