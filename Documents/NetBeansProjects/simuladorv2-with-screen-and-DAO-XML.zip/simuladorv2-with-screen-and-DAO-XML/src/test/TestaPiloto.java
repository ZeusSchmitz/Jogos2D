package test;

import model.Carro;
import model.Conservador;
import model.Piloto;
import model.Pista;

public class TestaPiloto {
    
    public void testaPiloto(Piloto p) {
        p.setCarro(new Carro("A, 10, 50, 10, 360"));
        for (int i = 0; i < 60 * 2; i++) {
            p.pulso();
            System.out.println(i + ") " + p.getCarro().getId() + ", V= "
                    + p.lookVelocimetro() + ", h=" + p.lookHodometro() 
                    + ", estado=" + p.getCarro().getEstado() + " | ");
        }
    }
    
    // testa o piloto dirigindo em uma pista
    public void testaPiloto(Piloto p, Pista s) {
        p.setCarro(new Carro("A, 10, 50, 10, 360"));
        p.setPista(s);
        //TODO: numero de loops deve ficar em funcao da extensao da pista
        for (int i = 0; i < 60 * 2; i++) {
            p.pulso();
            System.out.println(i + ") " + p.getCarro().getId() + ", V= "
                    + p.lookVelocimetro() + ", h=" + p.lookHodometro() 
                    + ", estado=" + p.getCarro().getEstado() + " | ");
        }
    }
    
    public static void main(String[] args) {
        
        TestaPiloto t = new TestaPiloto();
        t.testaPiloto(new Conservador());
        t.testaPiloto(new Conservador(), new Pista(5));
    }
    
}
