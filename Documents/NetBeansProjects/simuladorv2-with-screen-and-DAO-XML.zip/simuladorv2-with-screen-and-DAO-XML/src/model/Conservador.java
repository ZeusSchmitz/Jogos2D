package model;

public class Conservador extends Piloto {
    
    public void pulso() {
        
        // o piloto estah em um carro?
        if (this.getCarro() != null) {
            
            // o piloto estah dirigindo em uma pista?
            if (this.getPista() != null) {
                
                // se ultrapassou a extensao da pista, inicia a frenagem
                if (this.lookHodometro() >= this.getPista().getExtensao()) {
                  this.getCarro().setEstado("freiando");
                } 
            }
            // esse perfil sempre dah um pulso no carro
            this.getCarro().pulso();
        }
    }       
}
