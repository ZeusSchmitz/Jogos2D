
package model;

public abstract class Piloto {
    
    private Carro carro = null;
    private Pista pista = null;
    
    public abstract void pulso();
    
    public double lookHodometro() {
        return this.getCarro().getHodometro();
    }
    public double lookVelocimetro() {
        return this.getCarro().getVelocidadeAtual();
    }

    public Carro getCarro() {
        return carro;
    }

    public void setCarro(Carro carro) {
        this.carro = carro;
    }

    public Pista getPista() {
        return pista;
    }

    public void setPista(Pista pista) {
        this.pista = pista;
    }
    
}
