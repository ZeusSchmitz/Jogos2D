package controle;

import java.util.ArrayList;

import dao.usuario.UsuarioDAO;
import modelo.usuario.Usuario;

/**
 * Classe responsável por controlar os Usuários
 * @author Fernando
 *
 */
public class UsuarioControle {
	private ArrayList<Usuario> usuarios;
	private UsuarioDAO dao;

	public UsuarioControle() {
		dao = new UsuarioDAO();
		usuarios = dao.carregarUsuarios();
	}

	/**
	 * Adiciona um Usuario ao repositorio
	 * @param usuario Usuario a ser inserido
	 * @return true se foi possivel adicionar o Usuario
	 */
	public boolean adicionarUsuario(Usuario usuario) {
		try {
			usuarios.add(usuario);
			dao.salvarUsuarios(usuarios);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	/**
	 * 
	 * @param usuario Usuario a ser atualizado no repositorio
	 * @return true se foi possivel atualizar o Usuario
	 */
	public boolean atualizaUsuario(Usuario usuario) {
		for (Usuario usuarioAtual : usuarios) {
			if (usuario.equals(usuarioAtual)) {
				usuarioAtual = usuario;
				dao.salvarUsuarios(usuarios);
				return true;
			}
		}
		return false;
	}

	/**
	 * 
	 * @param usuario Usuario a ser removido do repositorio
	 * @return true se foi possivel remover o usuario
	 */
	public boolean removerUsuario(Usuario usuario) {
		if (usuarios.remove(usuario)) {
			dao.salvarUsuarios(usuarios);
			return true;
		}
		return false;
	}
	
	/**
	 *  Busca o usuario no repositorio, buscando pelo cpf
	 * @param cpf do Usuario a procurar no repositorio
	 * @return Usuario encontrado ou null
	 */
	public Usuario buscarUsuario(long cpf) {
		for (Usuario usuario : usuarios) {
			if (usuario.getCpf() == cpf) {
				return usuario;
			}
		}
		return null;
	}
	
	/**
	 * 
	 * @return ArrayList<Usuario> contendo todos usuários do repositorio
	 */
	public ArrayList<Usuario> getUsuarios() {
		return usuarios;
	}
}
