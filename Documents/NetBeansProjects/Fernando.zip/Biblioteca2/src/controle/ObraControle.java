package controle;

import java.util.ArrayList;

import dao.obra.ObraDAO;
import modelo.obra.Cd;
import modelo.obra.Livro;
import modelo.obra.Obra;

/**
 * Classe responsável para controlar a obra
 * @author Fernando
 *
 */
public class ObraControle {
	private ArrayList<Obra> obras;
	private ObraDAO dao;

	public ObraControle() {
		dao = new ObraDAO();
		obras = dao.carregarObras();
	}

	/**
	 * 
	 * @param obra Obra a ser adicionada no repositorio
	 * @return true se conseguiu adicionar
	 */
	public boolean adicionarObra(Obra obra) {
		try {
			for (Obra obraAtual : obras) {
				if (obra.equals(obraAtual)) {
					obraAtual.adicionarExemplar();
					dao.salvarObras(obras);
					return true;
				}
			}
			obra.adicionarExemplar();
			obras.add(obra);
			dao.salvarObras(obras);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	/**
	 *  
	 * @param obra Obra a ser atualizada no repositorio
	 * @return true se foi possivel atualizar a Obra
	 */
	public boolean atualizaObra(Obra obra) {
		for (Obra obraAtual : obras) {
			if (obra.equals(obraAtual)) {
				obraAtual = obra;
				dao.salvarObras(obras);
				return true;
			}
		}
		return false;
	}

	/**
	 * 
	 * @param obra Obra a ser removida do repositorio
	 * @return true se conseguiu remover a Obra
	 */
	public boolean removerObra(Obra obra) {
		if (obras.remove(obra)) {
			dao.salvarObras(obras);
			return true;
		}
		return false;
	}

	/**
	 *  Procura a Livro no repositorio, buscando pelo ISBN
	 * @param isbn 
	 * @return
	 */
	public Livro buscarPorIsbn(long isbn) {
		for (Obra obra : obras) {
			if (obra instanceof Livro) {
				if (((Livro) obra).getIsbn() == isbn) {
					return (Livro) obra;
				}
			}
		}
		return null;
	}
	
	/**
	 * 	Procura o Cd no repositorio, buscando pelo codigo de barras
	 * @param cdBarras
	 * @return
	 */
	public Cd buscarPorCdBarras(long cdBarras) {
		for (Obra obra : obras) {
			if (obra instanceof Cd) {
				if (((Cd)obra).getCodBarras() == cdBarras) {
					return(Cd) obra;
				}
			}
		}
		return null;
	}
	
	/**
	 * 
	 * @return ArrayList<Obra> contendo todas as Obras do repositorio
	 */
	public ArrayList<Obra> getObras() {
		return obras;
	}
}
