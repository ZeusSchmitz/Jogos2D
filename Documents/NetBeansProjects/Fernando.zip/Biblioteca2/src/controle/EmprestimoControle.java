package controle;

import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;

import dao.emprestimo.EmprestimoDAO;
import modelo.emprestimo.Emprestimo;
import modelo.obra.Exemplar;
import modelo.usuario.Aluno;
import modelo.usuario.Servidor;
import modelo.usuario.Usuario;

/**
 * Classe responsável pelo controle de emprestimos
 * 
 * @author Fernando
 *
 */
public class EmprestimoControle {
	private ArrayList<Emprestimo> emprestimos;
	private EmprestimoDAO dao;

	public EmprestimoControle() {
		dao = new EmprestimoDAO();
		emprestimos = dao.carregarEmprestimos();
	}

	/**
	 * Método utilizado para realizar o emprestimo no sistema
	 * 
	 * @param usuario
	 *            Usuário que está levando a obra emprestada
	 * @param exemplar
	 *            Exemplar da Obra a ser emprestada
	 * @param mensagem
	 *            Mensagem de aviso para o operador do sistema
	 * @return True se a obra pode ser emprestada, False se não pode.
	 */
	public boolean gravarEmprestimo(Usuario usuario, Exemplar exemplar, String mensagem) {
		if (usuario == null) {
			mensagem = "Usuário é obrigatório.";
			return false;
		}
		if (exemplar == null) {
			mensagem = "Obra é obrigatória.";
			return false;
		}
		boolean podeEmprestar = podeEmprestar(usuario, exemplar, mensagem);
		if (podeEmprestar) {
			Emprestimo emprestimo = new Emprestimo(LocalDate.now(), exemplar, usuario);
			emprestimos.add(emprestimo);
			dao.salvarEmprestimos(emprestimos);
		}
		return podeEmprestar;
	}

	/**
	 * Metodo que verifica se o usuário pode emprestar a obra. Este método
	 * valida se o usuário tem algum débido, caso tenha, informa na mensagem.
	 * Caso o débito seja maior que 10 dias de atrazo retorna que o usuario não
	 * pode emprestar a obra.
	 * 
	 * @param usuario
	 *            Usuário que está levando a obra emprestada
	 * @param exemplar
	 *            Exemplar da Obra a ser emprestada
	 * @param mensagem
	 *            Mensagem de aviso para o operador do sistema
	 * @return true se o usuário pode emprestar a obra e false, se não.
	 */
	private boolean podeEmprestar(Usuario usuario, Exemplar exemplar, String mensagem) {
		if (exemplar.getUsuarioReserva() != null) {
			if (!exemplar.getUsuarioReserva().equals(usuario)) {
				mensagem = "Este exemplar já possui uma reserva, não é possivel empresta-lo.";
				return false;
			} else {
				exemplar.setUsuarioReserva(null);
			}
		}

		long debito = 0;
		for (Emprestimo emprestimo : emprestimos) {
			if (emprestimo.getDataDevolucao() != null) {
				if (emprestimo.getUsuario().equals(usuario)) {
					if (!emprestimo.isQuitado()) {
						debito += emprestimo.getDiasAtrazo();
					}
				}
				if (debito > 10) {
					mensagem = "Não foi possivel realizar o emprestimo O usuário possui Debitos superior a 10 dias de atrazo.";
					return false;
				}
			} else {
				if (emprestimo.getExemplar().equals(exemplar)) {
					mensagem = "Este exemplar possui um Emprestimo em aberto, favor verificar.";
					return false;
				}
			}
		}
		if (debito > 0) {
			mensagem = "O usuário possui débito não quitado.";
		}
		return true;
	}

	/**
	 * Metodo que grava a devolução da obra e valida a quantidade de dias que
	 * ultrapassou da data de devolução de acordo com o tipo de Usuario Partindo
	 * da data de emprestimo: Aluno tem 14 dias para devolver a obra Servidor
	 * tem 30 dias para devolver a obra
	 * 
	 * @param exemplar
	 *            Exemplar da Obra a ser Devolvida
	 * @return Mensagem ao usuário caso tenha ultrapassado o limite de dias para
	 *         devolver a obra
	 */
	public String devolveObra(Exemplar exemplar) {
		Emprestimo emprestimo = buscaEmprestimoEmAberto(exemplar);
		if (emprestimo == null)
			return "Não Existe emprestimo para este exemplar.";

		String mensagem = "";

		if (emprestimo.getUsuario() instanceof Servidor) {
			emprestimo.setDataDevolucao(LocalDate.now());

			long dias = Period.between(emprestimo.getDataEmprestimo(), emprestimo.getDataDevolucao()).getDays();

			if (dias > 30) {
				emprestimo.setDiasAtrazo(dias - 30);
				mensagem = "Atrazo na devolução de " + emprestimo.getDiasAtrazo() + "dias.";
			} else {
				emprestimo.setQuitado(true);
			}

		} else if (emprestimo.getUsuario() instanceof Aluno) {
			emprestimo.setDataDevolucao(LocalDate.now());

			long dias = Period.between(emprestimo.getDataEmprestimo(), emprestimo.getDataDevolucao()).getDays();

			if (dias > 14) {
				emprestimo.setDiasAtrazo(dias - 14);
				mensagem = "Atrazo na devolução de " + emprestimo.getDiasAtrazo() + "dias.";
			} else {
				emprestimo.setQuitado(true);
			}
		}
		return mensagem;
	}

	/**
	 * 
	 * @param exemplar a ser buscado no repositorio de emprestimos
	 * @return Emprestimo sem data de devolução para o exemplar passado como parâmetro 
	 * 	ou null caso não encontre
	 */
	private Emprestimo buscaEmprestimoEmAberto(Exemplar exemplar) {
		for (Emprestimo emprestimo : emprestimos) {

			if (exemplar.equals(emprestimo.getExemplar())) {
				if (emprestimo.getDataDevolucao() == null) {
					return emprestimo;
				}
			}

		}
		return null;
	}

	/**
	 * Devolve a obra e realiza um novo emprestimo
	 * 
	 * @param exemplar
	 *            Exemplar a ser renovado o emprestimo
	 * @return mensagem ao usuário
	 */
	public String renovaEmprestimo(Exemplar exemplar) {
		Emprestimo emprestimo = buscaEmprestimoEmAberto(exemplar);
		if (emprestimo == null)
			return "Não Existe Emprestimo para o exemplar";

		String devolveObra = devolveObra(exemplar);
		String mensagem = "";
		gravarEmprestimo(emprestimo.getUsuario(), exemplar, mensagem);

		return mensagem != null ? mensagem : devolveObra != null ? devolveObra : "";
	}
}
