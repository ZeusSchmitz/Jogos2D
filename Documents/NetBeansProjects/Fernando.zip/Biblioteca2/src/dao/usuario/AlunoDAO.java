package dao.usuario;

import java.util.ArrayList;

import dao.DAOUtil;
import modelo.usuario.Aluno;

public class AlunoDAO {
	private final String endereco = "/Alunos.ser";

	public void salvarAlunos(ArrayList<Aluno> alunos) {
		DAOUtil.salvarLista(alunos, endereco);
	}

	public ArrayList<Aluno> carregarAlunos() {
		return DAOUtil.carregaLista(endereco);
	}

}
