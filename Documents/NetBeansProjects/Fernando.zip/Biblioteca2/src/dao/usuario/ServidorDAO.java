package dao.usuario;

import java.util.ArrayList;

import dao.DAOUtil;
import modelo.usuario.Servidor;

public class ServidorDAO {
	private final String endereco = "/Servidor.ser";

	public void salvarServidores(ArrayList<Servidor> servidores) {
		DAOUtil.salvarLista(servidores, endereco);
	}

	public ArrayList<Servidor> carregarServidores() {
		return DAOUtil.carregaLista(endereco);
	}

}
