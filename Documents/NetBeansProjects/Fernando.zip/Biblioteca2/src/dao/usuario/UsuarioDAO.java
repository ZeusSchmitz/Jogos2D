package dao.usuario;

import java.util.ArrayList;

import dao.DAOUtil;
import modelo.usuario.Usuario;

/**
 * Classe responsavel por gravar e carregar os Usuários salvos em arquivo
 * @author Fernando
 *
 */
public class UsuarioDAO extends DAOUtil  {
	private final String endereco = "/Usuarios.ser";

	/**
	 *	Salva um ArrayList<Usuario> no arquivo
	 * @param usuarios lista de usuários para salvar no arquivo
	 */
	public void salvarUsuarios(ArrayList<Usuario> usuarios) {
		salvarLista(usuarios, endereco);
	}

	/**
	 * 
	 * @return returna ArrayList<Usuario> com usuários salvos no arquivo 
	 */
	public ArrayList<Usuario> carregarUsuarios() {
		return carregaLista(endereco);
	}

}
