package dao.obra;

import java.util.ArrayList;

import dao.DAOUtil;
import modelo.obra.Obra;

/**
 * Classe responsavel por gravar e carregar as Obras salvas em arquivo
 * @author Fernando
 *
 */
public class ObraDAO extends DAOUtil {
	private final String endereco = "/Obras.ser";

	/**
	 * 
	 * @param obras ArrayList<Obra> a ser salvo no arquivo
	 */
	public void salvarObras(ArrayList<Obra> obras) {
		salvarLista(obras, endereco);
	}

	/**
	 *  
	 * @return o ArrayList<Obra> salvo no arquivo
	 */
	public ArrayList<Obra> carregarObras() {
		return carregaLista(endereco);
	}

}
