package dao.obra;

import java.util.ArrayList;

import dao.DAOUtil;
import modelo.obra.Cd;

public class CdDAO {
	private final String endereco = "/CD.ser";

	public void salvarCds(ArrayList<Cd> cd) {
		DAOUtil.salvarLista(cd, endereco);
	}
	
	public ArrayList<Cd> carregarCds(){
		return DAOUtil.carregaLista(endereco);
	}
	
}
