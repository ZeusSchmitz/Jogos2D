package dao.obra;

import java.util.ArrayList;

import dao.DAOUtil;
import modelo.obra.Livro;

public class LivroDAO {
	private final String endereco = "/Livros.ser";

	public void salvarLivros(ArrayList<Livro> livros) {
		DAOUtil.salvarLista(livros, endereco);
	}

	public ArrayList<Livro> carregarLivros() {
		return DAOUtil.carregaLista(endereco);
	}

}
