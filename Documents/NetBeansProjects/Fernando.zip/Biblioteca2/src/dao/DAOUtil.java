package dao;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

/**
 * Classe Responsável pela manipulação dos arquivos
 * @author Fernando
 *
 */
public abstract class DAOUtil {
	
	/**
	 * Verifica a existencia do arquivo do endereço diretorio, e caso não exista cria o arquivo
	 * @param diretorio endereço do arquivo a ser verificado
	 * @return File do arquivo criado ou encontrado
	 * @throws IOException
	 */
	private File verificaArquivo(String diretorio) throws IOException {
		File arquivo = new File(diretorio);
		if (!arquivo.exists()) {
			arquivo.createNewFile();
		}
		return arquivo;
	}


	/**
	 * 	
	 * @param endereco endereco onde será buscado a lista
	 * @return ArrayList do arquivo buscado
	 */
	@SuppressWarnings("unchecked")
	public <E> ArrayList<E> carregaLista(String endereco) {
		ObjectInputStream objectInputStream = null;
		FileInputStream fileInputStream = null;
		ArrayList<E> lista = new ArrayList<>();
		try {
			File file = verificaArquivo(endereco);
			if (file.length() > 0) {
				try {
					fileInputStream = new FileInputStream(file);
					objectInputStream = new ObjectInputStream(fileInputStream);
					lista = (ArrayList<E>) objectInputStream.readObject();
				} finally {
					if (objectInputStream != null) {
						objectInputStream.close();
					}
					if (fileInputStream != null) {
						fileInputStream.close();
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return lista;
	}

	/**
	 * 
	 * @param lista ArrayList a ser salvo em um arquivo endereco
	 * @param endereco diretorio a ser salvo o arquivo
	 */
	public <E> void salvarLista(ArrayList<E> lista, String endereco) {
		FileOutputStream stream = null;
		ObjectOutputStream objectStream = null;
		try {
			try {
				File arquivo = verificaArquivo(endereco);
				stream = new FileOutputStream(arquivo);
				objectStream = new ObjectOutputStream(stream);
				objectStream.writeObject(lista);
			} finally {
				stream.close();
				objectStream.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
