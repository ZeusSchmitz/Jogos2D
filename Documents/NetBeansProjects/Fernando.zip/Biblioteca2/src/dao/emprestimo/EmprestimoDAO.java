package dao.emprestimo;

import java.util.ArrayList;

import dao.DAOUtil;
import modelo.emprestimo.Emprestimo;

/**
 * Classe responsável por manipular os emprestimos salvos em arquivo
 * @author Fernando
 *
 */
public class EmprestimoDAO extends DAOUtil {
	private final String endereco = "/Emprestimo.ser";

	/**
	 * 
	 * @param emprestimos ArrayList<Emprestimo>  a ser salvo no arquivo
	 */
	public void salvarEmprestimos(ArrayList<Emprestimo> emprestimos) {
		salvarLista(emprestimos, endereco);
	}

	/**
	 * 
	 * @return ArrayList<Emprestimo> salvo no arquivo
	 */
	public ArrayList<Emprestimo> carregarEmprestimos() {
		return carregaLista(endereco);
	}

}
