//package teste;
//
//import java.util.ArrayList;
//import java.util.Date;
//
//import dao.emprestimo.EmprestimoDAO;
//import dao.obra.CdDAO;
//import dao.obra.LivroDAO;
//import dao.usuario.AlunoDAO;
//import dao.usuario.ServidorDAO;
//import modelo.emprestimo.Emprestimo;
//import modelo.obra.Cd;
//import modelo.obra.Livro;
//import modelo.usuario.Aluno;
//import modelo.usuario.Servidor;
//
//public class TesteDAO {
//	
//	public static void main(String[] args) {
//		testeLivro();
//		testeAluno();
//		testeServidor();
//		testeCd();
//		testeEmprestimo();
//	}
//
//	private static void testeEmprestimo() {
//		EmprestimoDAO emprestimoDAO = new EmprestimoDAO();
//		AlunoDAO alunoDAO = new AlunoDAO();
//		LivroDAO livroDAO = new LivroDAO();
//		ArrayList<Emprestimo> emprestimos = emprestimoDAO.carregarEmprestimos();
//		ArrayList<Aluno> alunos = alunoDAO.carregarAlunos();
//		ArrayList<Livro> livros = livroDAO.carregarLivros();
//		
//		Emprestimo emprestimo = new Emprestimo(new Date(),  , alunos.get(0));
//		System.out.println(emprestimo);
//		
//		emprestimos.add(emprestimo);
//		
//		emprestimoDAO.salvarEmprestimos(emprestimos);
//		
//		emprestimos = emprestimoDAO.carregarEmprestimos();
//		
//		for (Emprestimo emprestimo2 : emprestimos) {
//			System.out.println(emprestimo2);
//		}
//		
//		for (Livro livro : livros) {
//			for (Livro livro : livro.ge) {
//				
//			}
//		}
//		
//	}
//
//	private static void testeLivro() {
//		LivroDAO livroDAO = new LivroDAO();
//		ArrayList<Livro> livros = livroDAO.carregarLivros();
//		ArrayList<String> lista = new ArrayList<>();
//
//		lista.add("Fernando Staroski");
//		lista.add("Rosana Crestani");
//		Livro livro = new Livro("Livro Teste", new Date(), lista, "Editora", 1234, 1, "159357853",
//				"Coleção de Livro Teste", 2, null);
//		livros.add(livro);
//
//		livroDAO.salvarLivros(livros);
//
//		livros = livroDAO.carregarLivros();
//
//		for (Livro livro2 : livros) {
//			System.out.println(livro2.toString());
//		}
//	}
//
//	private static void testeAluno() {
//		AlunoDAO dao = new AlunoDAO();
//		Aluno aluno = new Aluno("Fernando Staroski", 383189);
//		Aluno aluno2 = new Aluno("Rosana Crestani", 123456);
//		ArrayList<Aluno> alunos = dao.carregarAlunos();
//		alunos.add(aluno);
//		alunos.add(aluno2);
//
//		dao.salvarAlunos(alunos);
//
//		alunos = dao.carregarAlunos();
//
//		for (Aluno aluno3 : alunos) {
//			System.out.println(aluno3);
//		}
//	}
//
//	private static void testeServidor() {
//		ServidorDAO dao = new ServidorDAO();
//		Servidor servidor = new Servidor("Fernando Staroski", 25646632);
//		Servidor servidor2 = new Servidor("Rosana", 8765453);
//		ArrayList<Servidor> servidores = dao.carregarServidores();
//		servidores.add(servidor2);
//		servidores.add(servidor);
//
//		dao.salvarServidores(servidores);
//
//		for (Servidor servidor3 : servidores) {
//			System.out.println(servidor3);
//		}
//	}
//
//	private static void testeCd() {
//		CdDAO dao = new CdDAO();
//		ArrayList<Cd> cds = dao.carregarCds();
//		ArrayList<String> lista = new ArrayList<>();
//		lista.add("Armin van buuren");
//		Cd cd = new Cd("Embrace", new Date(), lista);
//		Cd cd2 = new Cd("Imagine", new Date(), lista);
//
//		cds.add(cd2);
//		cds.add(cd);
//
//		dao.salvarCds(cds);
//
//		for (Cd cd3 : cds) {
//			System.out.println(cd3);
//		}
//	}
//}
