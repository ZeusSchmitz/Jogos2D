package teste;

import java.util.ArrayList;

import controle.EmprestimoControle;
import controle.ObraControle;
import controle.UsuarioControle;
import modelo.obra.Cd;
import modelo.obra.Exemplar;
import modelo.obra.Livro;
import modelo.obra.Obra;
import modelo.usuario.Aluno;
import modelo.usuario.Servidor;
import modelo.usuario.Usuario;

public class TesteControle {
	public static void main(String[] args) {
		ObraControle obraControle = new ObraControle();
		UsuarioControle usuarioControle = new UsuarioControle();
		EmprestimoControle emprestimoControle = new EmprestimoControle();

		testeEmprestimo(emprestimoControle);
		testeObra(obraControle);
		testeUsuario(usuarioControle);
		
	}

	private static void testeEmprestimo(EmprestimoControle emprestimoControle) {
		String mensagem = "";
		Aluno aluno = new Aluno("Fernando Staroski", Long.valueOf("07365363967"));
		Livro livro = new Livro("Livro", 1990 ,"Fernando","EditoraTeste",123456,123,"classificacaoTeste","colecao",123,null);
		Exemplar exemplar = livro.getExemplares().get(0);
		emprestimoControle.gravarEmprestimo(
				aluno,
				exemplar, 
				mensagem);
		System.out.println(mensagem);
	}

	private static void testeObra(ObraControle obraControle) {
		Obra livro1 = new Livro(" asdf", 1990, "eu", "minha", 4564654, 1231, "class", "123", 123, null);
		Cd cd2 = new Cd("asdf", 1990, "asdfas", 646545654);
		obraControle.adicionarObra(cd2);
		obraControle.adicionarObra(livro1);
		ArrayList<Obra> obras = obraControle.getObras();
		for (Obra obra : obras) {
			System.out.println(obra.getTitulo());
			System.out.println(obra);
			for (Exemplar exemplar : obra.getExemplares()) {
				System.out.println(exemplar);
			}
		}
		obras.get(0).setTitulo("AtualizaTitulo " + System.currentTimeMillis());
		obraControle.atualizaObra(obras.get(0));
		obraControle.removerObra(obras.get(1));
		obraControle.adicionarObra(obras.get(1));
	}

	private static void testeUsuario(UsuarioControle usuarioControle) {
		Usuario aluno1 = new Aluno("Fernando Staroski", 189465321);
		Aluno aluno2 = new Aluno("Fernando Staroski", 189465321);
		Servidor servidor3 = new Servidor("Fernando Staroski", 189465321);
		Aluno aluno4 = new Aluno("Fernando Staroski", 189465321);
		Usuario servidor1 = new Servidor("Rosana Crestani", 23165431);
		Servidor servidor2 = new Servidor("Rosana Crestani", 23165431);
		Aluno aluno3 = new Aluno("Rosana Crestani", 23165431);
		Servidor servidor4 = new Servidor("Rosana Crestani", 23165431);
		usuarioControle.adicionarUsuario(aluno1);
		usuarioControle.adicionarUsuario(aluno2);
		usuarioControle.adicionarUsuario(aluno3);
		usuarioControle.adicionarUsuario(aluno4);
		usuarioControle.adicionarUsuario(servidor1);
		usuarioControle.adicionarUsuario(servidor2);
		usuarioControle.adicionarUsuario(servidor3);
		usuarioControle.adicionarUsuario(servidor4);

		ArrayList<Usuario> usuarios = usuarioControle.getUsuarios();

		for (Usuario usuario : usuarios) {
			System.out.println(usuario);
		}
	}
}
