package teste;

import java.time.LocalDate;

import modelo.emprestimo.Emprestimo;
import modelo.obra.Cd;
import modelo.obra.Livro;
import modelo.usuario.Aluno;

public class TesteEmprestimo {
	public static void main(String[] args) {
		Emprestimo emprestimo = new Emprestimo(LocalDate.now(),
				new Livro("Teste1", 1990, "Fernando", "EditoraTeste", 1230000l, 50, "classificacaoTeste",
						"colecaoTeste", 123, new Cd("tituloCd", 1990, "123", 231)).getExemplares().get(0),
				new Aluno("Fernando", 123456));

		System.out.println(emprestimo);

		emprestimo.setDataDevolucao(LocalDate.now());
		emprestimo.setQuitado(true);
		System.out.println(emprestimo.getDataEmprestimo());
		System.out.println(emprestimo.isQuitado());
	}
}
