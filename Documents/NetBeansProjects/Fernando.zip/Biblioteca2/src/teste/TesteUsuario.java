package teste;

import modelo.usuario.Aluno;
import modelo.usuario.Servidor;
import modelo.usuario.Usuario;

public class TesteUsuario {

	public static void main(String[] args) {
		Usuario aluno1 = new Aluno("Fernando Staroski", 189465321);
		Aluno aluno2 = new Aluno("Fernando Staroski", 189465321);
		Servidor servidor3 = new Servidor("Fernando Staroski", 189465321);
		Aluno aluno4 = new Aluno("Fernando Staroski", 189465321);
		
		Usuario servidor1 = new Servidor("Rosana Crestani", 23165431);
		Servidor servidor2 = new Servidor("Rosana Crestani", 23165431);
		Aluno aluno3 = new Aluno("Rosana Crestani", 23165431);
		Servidor servidor4 = new Servidor("Rosana Crestani", 23165431);
		
		
		
		System.out.println(aluno1.equals(aluno2));
		System.out.println(aluno1.equals(servidor1));
		System.out.println(aluno1.equals(servidor2));
		System.out.println(aluno1.equals(servidor3));
		System.out.println(aluno2.equals(servidor3));
		System.out.println(aluno2.equals(aluno4));
		System.out.println();
		System.out.println(servidor1.equals(servidor2));
		System.out.println(servidor1.equals(aluno1));
		System.out.println(servidor1.equals(aluno2));
		System.out.println(servidor1.equals(aluno3));
		System.out.println(servidor2.equals(aluno3));
		System.out.println(servidor1.equals(servidor4));
		System.out.println();
		System.out.println(aluno1);
		System.out.println(aluno2);
		System.out.println(aluno3);
		System.out.println(aluno4);
		System.out.println();
		System.out.println(servidor1);
		System.out.println(servidor2);
		System.out.println(servidor3);
		System.out.println(servidor4);
		
	}
}
