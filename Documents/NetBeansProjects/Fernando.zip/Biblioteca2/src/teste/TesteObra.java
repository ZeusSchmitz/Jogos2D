package teste;

import modelo.obra.Cd;
import modelo.obra.Livro;
import modelo.obra.Obra;

public class TesteObra {
	public static void main(String[] args) {
		Obra livro1 = new Livro(" asdf", 1990,"eu",  "minha", 4564654, 1231,"class", "123", 123,null  );
		Obra livro2 = new Livro(" asdf", 1990,"eu", "minha", 4564654, 1231,"class", "123", 123,null  );
		Obra cd1 = new Cd("asdf", 1990, "asdfas",123123);
		Livro livro3 = new Livro(" asdf", 1990,"eu",  "minha", 4564654, 1231,"class", "123", 123,null  );
		Livro livro4 = new Livro(" asdf", 1990,"eu",  "minha", 45646524, 1231,"class", "123", 123,null  );
		Cd cd2 = new Cd("asdf", 1990, "asdfas",646545654);
		
		System.out.println(cd2.equals(livro4));
		System.out.println(livro1.equals(cd1));
		System.out.println(livro1.equals(cd2));
		System.out.println(livro1.equals(livro2));
		System.out.println(livro1.equals(livro3));
		System.out.println(livro1.equals(livro4));
		System.out.println(livro1.equals(cd1));
		
		
	}
}
