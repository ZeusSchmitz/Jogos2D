package modelo.usuario;

public class Servidor extends Usuario {

	private static final long serialVersionUID = -6220930875683107397L;

	public Servidor(String nome, long cpf) {
		super(nome, cpf);
	}

	@Override
	public String toString() {
		return "Servidor [getNome()=" + getNome() + ", getCpf()=" + getCpf() + "]";
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (getCpf() ^ (getCpf() >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Usuario other = (Usuario) obj;
		if (getCpf() != other.getCpf())
			return false;
		return true;
	}
}
