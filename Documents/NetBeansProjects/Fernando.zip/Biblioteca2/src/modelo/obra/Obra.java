package modelo.obra;

import java.io.Serializable;
import java.util.ArrayList;

public abstract class Obra implements Serializable {

	private static final long serialVersionUID = 5697312861057315782L;
	private String titulo;
	private int ano;
	private String autores;
	private ArrayList<Exemplar> exemplares;

	public Obra(String titulo, int ano, String autores) {
		this.titulo = titulo;
		this.ano = ano;
		this.autores = autores;
	}

	@Override
	public String toString() {
		return "Obra [titulo=" + titulo + ", ano=" + ano + ", autores=" + autores + "]";
	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public int getAno() {
		return ano;
	}

	public void setAno(int ano) {
		this.ano = ano;
	}

	public String getAutores() {
		return autores;
	}

	public void setAutores(String autores) {
		this.autores = autores;
	}

	public void adicionarExemplar() {
		if (exemplares == null)
			exemplares = new ArrayList<Exemplar>();
		Exemplar exemplar = new Exemplar(this);
		if (exemplares.isEmpty()) {
			exemplar.setNumero(1);
		} else {
			exemplar.setNumero(exemplares.size() + 1);
		}
		exemplares.add(exemplar);
	}

	public ArrayList<Exemplar> getExemplares() {
		return exemplares;
	}
}
