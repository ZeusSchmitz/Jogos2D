package modelo.obra;

import java.io.Serializable;

public class Cd extends Obra implements Serializable {

	private static final long serialVersionUID = 1L;
	private long codBarras;

	public Cd(String titulo, int ano, String autores, long cdBarras) {
		super(titulo, ano, autores);
		this.codBarras = cdBarras;
	}
	

	public long getCodBarras() {
		return codBarras;
	}


	@Override
	public String toString() {
		return "Cd [toString()=" + super.toString() + ", getTitulo()=" + getTitulo() + ", getAno()=" + getAno()
				+ ", getAutores()=" + getAutores() + ", hashCode()=" + hashCode() + ", getClass()=" + getClass() + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (codBarras ^ (codBarras >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (!(obj instanceof Cd))
			return false;
		Cd other = (Cd) obj;
		if (codBarras != other.codBarras)
			return false;
		return true;
	}
	
	
}
