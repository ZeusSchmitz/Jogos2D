package modelo.obra;

import java.io.Serializable;

import modelo.usuario.Usuario;

public class Exemplar implements Serializable {

	private static final long serialVersionUID = 2002620896400136163L;
	private int numero;
	private int patrimonio;
	private long codigoBarra;
	private Obra obra;
	private Usuario usuarioReserva;


	public Exemplar(Obra obra) {
		this.obra = obra;
	}

	public Usuario getUsuarioReserva() {
		return usuarioReserva;
	}

	public void setUsuarioReserva(Usuario usuarioReserva) {
		this.usuarioReserva = usuarioReserva;
	}

	public Obra getObra() {
		return obra;
	}

	public int getNumero() {
		return numero;
	}

	public void setNumero(int numero) {
		this.numero = numero;
	}

	public int getPatrimonio() {
		return patrimonio;
	}

	public void setPatrimonio(int patrimonio) {
		this.patrimonio = patrimonio;
	}

	public long getCodigoBarra() {
		return codigoBarra;
	}

	public void setCodigoBarra(long codigoBarra) {
		this.codigoBarra = codigoBarra;

	}

	@Override
	public String toString() {
		return "Exemplar [numero=" + numero + ", patrimonio=" + patrimonio + ", codigoBarra=" + codigoBarra + "]";
	}

}
