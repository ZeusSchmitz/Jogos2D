
package modelo.obra;

import java.io.Serializable;

public class Livro extends Obra implements Serializable {

	private static final long serialVersionUID = 7249399136218263198L;
	private String editora;
	private long isbn;
	private int numeroPaginas;
	private String classificacao;
	private String colecao;
	private int edicao;
	private Cd cd;

	public Livro(String titulo, int ano, String autores, String editora, long isbn, int numeroPaginas,
			String classificacao, String colecao, int edicao, Cd cd) {
		super(titulo, ano, autores);
		this.editora = editora;
		this.isbn = isbn;
		this.numeroPaginas = numeroPaginas;
		this.classificacao = classificacao;
		this.colecao = colecao;
		this.edicao = edicao;
		this.cd = cd;
	}

	@Override
	public String toString() {
		return "Livro [editora=" + editora + ", isbn=" + isbn + ", numeroPaginas=" + numeroPaginas + ", classificacao="
				+ classificacao + ", colecao=" + colecao + ", edicao=" + edicao + ", cd=" + cd + "]";
	}

	public String getEditora() {
		return editora;
	}

	public void setEditora(String editora) {
		this.editora = editora;
	}

	public long getIsbn() {
		return isbn;
	}

	public void setIsbn(long isbn) {
		this.isbn = isbn;
	}

	public int getNumeroPaginas() {
		return numeroPaginas;
	}

	public void setNumeroPaginas(int numeroPaginas) {
		this.numeroPaginas = numeroPaginas;
	}

	public String getClassificacao() {
		return classificacao;
	}

	public void setClassificacao(String classificacao) {
		this.classificacao = classificacao;
	}

	public String getColecao() {
		return colecao;
	}

	public void setColecao(String colecao) {
		this.colecao = colecao;
	}

	public int getEdicao() {
		return edicao;
	}

	public void setEdicao(int edicao) {
		this.edicao = edicao;
	}

	public Cd getCd() {
		return cd;
	}

	public void setCd(Cd cd) {
		this.cd = cd;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (isbn ^ (isbn >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (!(obj instanceof Livro))
			return false;
		Livro other = (Livro) obj;
		if (isbn != other.isbn)
			return false;
		return true;
	}
	
	
	
}
