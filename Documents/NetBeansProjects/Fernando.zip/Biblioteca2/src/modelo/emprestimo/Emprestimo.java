package modelo.emprestimo;

import java.io.Serializable;
import java.time.LocalDate;

import modelo.obra.Exemplar;
import modelo.obra.Obra;
import modelo.usuario.Usuario;

public class Emprestimo implements Serializable {

	private static final long serialVersionUID = -7873163728008448912L;
	private LocalDate dataEmprestimo;
	private Exemplar exemplar;
	private Usuario usuario;
	private LocalDate dataDevolucao;
	private boolean quitado = false;
	private long diasAtrazo;

	public Emprestimo(LocalDate dataEmprestimo, Exemplar exemplar, Usuario usuario) {
		super();
		this.dataEmprestimo = dataEmprestimo;
		this.exemplar = exemplar;
		this.usuario = usuario;
	}

	@Override
	public String toString() {
		return "Emprestimo [dataEmprestimo=" + dataEmprestimo + ", obra=" + exemplar.getObra() + ", usuario=" + usuario
				+ ", dataDevolucao=" + dataDevolucao + "]";
	}

	public LocalDate getDataEmprestimo() {
		return dataEmprestimo;
	}

	public Exemplar getExemplar() {
		return exemplar;
	}

	public void setDataEmprestimo(LocalDate dataEmprestimo) {
		this.dataEmprestimo = dataEmprestimo;
	}

	public Obra getObra() {
		return exemplar.getObra();
	}

	public Usuario getUsuario() {
		return usuario;
	}

	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}

	public LocalDate getDataDevolucao() {
		return dataDevolucao;
	}

	public void setDataDevolucao(LocalDate dataDevolucao) {
		this.dataDevolucao = dataDevolucao;
	}

	public boolean isQuitado() {
		return quitado;
	}

	public void setQuitado(boolean quitado) {
		this.quitado = quitado;
	}

	public long getDiasAtrazo() {
		return diasAtrazo;
	}

	public void setDiasAtrazo(long diasAtrazo) {
		this.diasAtrazo = diasAtrazo;
	}

}
