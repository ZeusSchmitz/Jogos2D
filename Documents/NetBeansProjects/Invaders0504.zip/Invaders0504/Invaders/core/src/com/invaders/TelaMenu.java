package com.invaders;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.InputAdapter;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;

public class TelaMenu implements Screen {

    Invaders game = null;
    Texture botaoJogar, botaoJogarSelecionado, botaoSair, botaoSairSelecionado;

    public TelaMenu(final Invaders game) {
        this.game = game;
        botaoJogar = new Texture(Gdx.files.internal("jogar.png"));
        botaoJogarSelecionado = new Texture(Gdx.files.internal("jogarselecionado.png"));
        botaoSair = new Texture(Gdx.files.internal("sair.png"));
        botaoSairSelecionado = new Texture(Gdx.files.internal("sairselecionado.png"));

        final TelaMenu tela = this;
        Gdx.input.setInputProcessor(new InputAdapter() {

            @Override
            public boolean touchDown(int screenX, int screenY, int pointer, int button) {
                if (testaBotaoJogar(screenX, screenY)) {
                    tela.dispose();
                    game.setScreen(new TelaJogo(game));
                }
                return true;
            }
        });
    }

    public boolean testaBotaoJogar(float x, float y) {
        return x > botaoJogarX
                && x < botaoJogarX + botaoJogarLar
                && y < game.ALTURA - botaoJogarY
                && y > game.ALTURA - (botaoJogarY + botaoJogarAlt);
    }

    @Override
    public void show() {
    }

    int botaoJogarAlt = 150;
    int botaoJogarLar = 200;
    int botaoJogarX = 200;
    int botaoJogarY = 400;

    @Override
    public void render(float delta) {
        Gdx.gl.glClearColor(1, 1, 1, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        game.batch.begin();
        if (testaBotaoJogar(Gdx.input.getX(), Gdx.input.getY())) {
            game.batch.draw(botaoJogarSelecionado, botaoJogarX, botaoJogarY);
        } else {
            game.batch.draw(botaoJogar, botaoJogarX, botaoJogarY);
        }
        game.batch.draw(botaoSair, 200, 200);
        game.batch.end();
    }

    @Override
    public void resize(int width, int height) {
    }

    @Override
    public void pause() {
    }

    @Override
    public void resume() {
    }

    @Override
    public void hide() {
    }

    @Override
    public void dispose() {
        botaoJogar.dispose();
        botaoJogarSelecionado.dispose();
        botaoSair.dispose();
        botaoSairSelecionado.dispose();
    }

}
