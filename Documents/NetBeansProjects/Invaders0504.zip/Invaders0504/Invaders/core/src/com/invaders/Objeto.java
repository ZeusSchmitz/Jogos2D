package com.invaders;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public class Objeto {

    private final Texture textura;
    private int x;
    private int y;
    private final int velH;
    private final int velV;

    private Sound somDisparo;
    private long idSomDisparo = 0;

    public void efeitoSonoro() {
        
        somDisparo.stop(idSomDisparo);
        idSomDisparo = somDisparo.play();
    }

    public Objeto(Texture textura, int x, int y,
            int velH, int velV) {
        somDisparo = Gdx.audio.newSound(Gdx.files.internal("bomb.mp3"));
        this.textura = textura;
        this.x = x;
        this.y = y;
        this.velH = velH;
        this.velV = velV;
    }

    public void desenha(SpriteBatch batch) {
        batch.draw(textura, x, y);
    }

    void movimentaAbaixo() {
        if (y - this.velV >= 0) {
            y -= this.velV;
        }
    }

    void movimentaAcima() {
        if (y + textura.getHeight() + this.velV <= Invaders.ALTURA) {
            y += this.velV;
        }
    }

    public Objeto criaDisparo(Texture texturaDisparo) {
        int x = (this.x + this.textura.getWidth());
        int y = (this.y + this.textura.getHeight() / 2)
                - (texturaDisparo.getHeight() / 2);
        Objeto disp = new Objeto(texturaDisparo,
                x, y, velH, velV);
        return disp;
    }

    protected int getX() {
        return this.x;
    }

    protected int getY() {
        return this.y;
    }

    protected int getW() {
        return this.textura.getWidth();
    }

    protected int getH() {
        return this.textura.getHeight();
    }

    public boolean colide(Objeto objeto) {
        // bounding box: intesecção de pontos.
        return (x < objeto.getX() + objeto.getW()
                && x + getW() > objeto.getX()
                && y < objeto.getY() + objeto.getH()
                && y + getH() > objeto.getY());
    }

    void movimentaDireita() {
        x += velH;
    }

    void movimentaEsquerda() {
        x -= velH;
    }
}
