package servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebListener;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 * Servlet implementation class ServletAula1
 */

@WebServlet(name="hello", value={"/meuPrimeiroServlet","/teste"}, 
			initParams= {@WebInitParam(name="teste", value="10")})
public class ServletAula1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ServletAula1() {
        super();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 * 
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		processar(request, response,"doGet");
	}

	protected void processar(HttpServletRequest request, HttpServletResponse response,String tipo) throws ServletException, IOException {
		String[] lista = new String[10];
		
		for(int i=0;i<10;i++)
			lista[i]=request.getParameter("nome_usuario")+i;
		
		request.setAttribute("lista", lista);
		request.getRequestDispatcher("index.jsp").forward(request, response);
		System.out.println("A pedido da Pricila"+request.getParameter("nome_usuario"));
	}
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		processar(request, response,"doPost");
	}

}
