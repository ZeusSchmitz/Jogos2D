package servlet.listener;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebListener;

import com.sun.xml.internal.ws.api.WSService.InitParams;

/**
 * Application Lifecycle Listener implementation class CriarUsuarioInicial
 *
 */
@WebListener
@WebInitParam(name="teste",value="teste")
public class CriarUsuarioInicial implements ServletContextListener {

    /**
     * Default constructor. 
     */
    public CriarUsuarioInicial() {
        // TODO Auto-generated constructor stub
    }

	/**
     * @see ServletContextListener#contextDestroyed(ServletContextEvent)
     */
    public void contextDestroyed(ServletContextEvent arg0)  { 
         // TODO Auto-generated method stub
    	System.out.print("Finalizando a aplicação web");
    }

	/**
     * @see ServletContextListener#contextInitialized(ServletContextEvent)
     */
    public void contextInitialized(ServletContextEvent arg0)  {
    	
    	System.out.print("Começando a executar a aplicação web");
    }
	
}
