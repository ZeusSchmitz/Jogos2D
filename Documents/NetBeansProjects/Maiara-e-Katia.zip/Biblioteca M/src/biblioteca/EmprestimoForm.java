package biblioteca;

import java.util.ArrayList;
import javax.swing.JOptionPane;

public class EmprestimoForm extends javax.swing.JFrame {

    public EmprestimoForm() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        edNome = new javax.swing.JTextField();
        edCPFPessoa = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        edDataDevolucao = new javax.swing.JTextField();
        BtnReservar = new javax.swing.JButton();
        BtnEmprestar = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        btnPesquisarObrasEmprestadas = new javax.swing.JButton();
        btnRenovar = new javax.swing.JButton();
        btnDevolver = new javax.swing.JButton();
        cbEmprestimos = new javax.swing.JComboBox<>();
        jLabel4 = new javax.swing.JLabel();
        edVoltar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        edNome.setName("edNome"); // NOI18N

        edCPFPessoa.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                edCPFPessoaFocusLost(evt);
            }
        });

        jLabel1.setText("Nome da obra");

        jLabel2.setText("CPF da Pessoa");

        BtnReservar.setText("Reservar");
        BtnReservar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnReservarActionPerformed(evt);
            }
        });

        BtnEmprestar.setText("Emprestar");
        BtnEmprestar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnEmprestarActionPerformed(evt);
            }
        });

        jLabel3.setText("Data de devolução");

        btnPesquisarObrasEmprestadas.setText("Pesquisar obras emprestadas");
        btnPesquisarObrasEmprestadas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPesquisarObrasEmprestadasActionPerformed(evt);
            }
        });

        btnRenovar.setText("Renovar");
        btnRenovar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRenovarActionPerformed(evt);
            }
        });

        btnDevolver.setText("Devolver");
        btnDevolver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDevolverActionPerformed(evt);
            }
        });

        cbEmprestimos.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                cbEmprestimosFocusLost(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel4.setText("PAINEL DE EMPRÉSTIMOS");

        edVoltar.setText("Voltar");
        edVoltar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                edVoltarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(150, 150, 150)
                        .addComponent(jLabel4))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(BtnEmprestar, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnRenovar, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(BtnReservar, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnDevolver, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(edVoltar, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jLabel1)
                                .addComponent(jLabel3))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(23, 23, 23)
                                .addComponent(jLabel2)))
                        .addGap(1, 1, 1)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(edDataDevolucao, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(edNome, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(edCPFPessoa, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(btnPesquisarObrasEmprestadas))))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(cbEmprestimos, javax.swing.GroupLayout.PREFERRED_SIZE, 204, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel4)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(edCPFPessoa, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnPesquisarObrasEmprestadas))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(cbEmprestimos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(edNome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(edDataDevolucao, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addGap(47, 47, 47)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(edVoltar)
                    .addComponent(BtnEmprestar)
                    .addComponent(btnRenovar)
                    .addComponent(BtnReservar)
                    .addComponent(btnDevolver))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void BtnReservarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnReservarActionPerformed
        Emprestimo emp = new Emprestimo();
        emp.Reservar(edNome.getText(), Integer.parseInt(edCPFPessoa.getText()), true);

    }//GEN-LAST:event_BtnReservarActionPerformed

    private void BtnEmprestarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnEmprestarActionPerformed
        Emprestimo emp = new Emprestimo();
        emp.Emprestar(Integer.valueOf(edCPFPessoa.getText()), edNome.getText(), edDataDevolucao.getText());
    }//GEN-LAST:event_BtnEmprestarActionPerformed

    private void edCPFPessoaFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_edCPFPessoaFocusLost
        boolean pessoaEhServidor = false;
        Emprestimo emp = new Emprestimo();

        try {
            PessoaDAO pessoaDAO = new PessoaDAO();
            ArrayList<Pessoa> grupo = new ArrayList();
            grupo = pessoaDAO.carregarPessoas();

            for (Pessoa p : grupo) {

                if ((Integer.valueOf(edCPFPessoa.getText()) == p.getCPF())) {
                    //emp.setPessoa(p);
                    pessoaEhServidor = p.isEhServidor();
                    break;
                }
            }
            edDataDevolucao.setText(emp.calcularDataDevolucao(pessoaEhServidor));

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro ao Pesquisar livro: " + e.getMessage());
        }
    }//GEN-LAST:event_edCPFPessoaFocusLost

    private void btnPesquisarObrasEmprestadasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPesquisarObrasEmprestadasActionPerformed
        EmprestimoDAO emprestimoDAO = new EmprestimoDAO();
        ArrayList<Emprestimo> emprestimos = new ArrayList();
        emprestimos = emprestimoDAO.carregaEmprestimos();
        cbEmprestimos.setSelectedItem(null);
        cbEmprestimos.removeAllItems();
        boolean encontrou = false;
        for (Emprestimo em : emprestimos) {
            if (em.getPessoa().getCPF() == Integer.parseInt(edCPFPessoa.getText())) {
                encontrou = true;
                cbEmprestimos.addItem(em.getObra().getTitulo());
            }
        }
        if (!encontrou) {
            cbEmprestimos.addItem("Usuário sem empréstimos");
        }
    }//GEN-LAST:event_btnPesquisarObrasEmprestadasActionPerformed

    private void btnRenovarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRenovarActionPerformed
        try {
            Emprestimo emp = new Emprestimo();
            emp.Renovar(Integer.valueOf(edCPFPessoa.getText()), edNome.getText());
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }//GEN-LAST:event_btnRenovarActionPerformed

    private void btnDevolverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDevolverActionPerformed
    Emprestimo emp = new Emprestimo();
        emp.Devolver(Integer.valueOf(edCPFPessoa.getText()),edNome.getText(), edDataDevolucao.getText() );
    }//GEN-LAST:event_btnDevolverActionPerformed

    private void edVoltarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_edVoltarActionPerformed
        this.dispose();
    }//GEN-LAST:event_edVoltarActionPerformed

    private void cbEmprestimosFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_cbEmprestimosFocusLost
       edNome.setText((String) cbEmprestimos.getSelectedItem());
    }//GEN-LAST:event_cbEmprestimosFocusLost
 
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;

                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(EmprestimoForm.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(EmprestimoForm.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(EmprestimoForm.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(EmprestimoForm.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new EmprestimoForm().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BtnEmprestar;
    private javax.swing.JButton BtnReservar;
    private javax.swing.JButton btnDevolver;
    private javax.swing.JButton btnPesquisarObrasEmprestadas;
    private javax.swing.JButton btnRenovar;
    private javax.swing.JComboBox<String> cbEmprestimos;
    private javax.swing.JTextField edCPFPessoa;
    private javax.swing.JTextField edDataDevolucao;
    private javax.swing.JTextField edNome;
    private javax.swing.JButton edVoltar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    // End of variables declaration//GEN-END:variables
}
