package biblioteca;

public class Livro extends Obra{ 
 private int numPaginas;
 private String editora;
 private String ISBN;
 private Cd cd;
 private int NroExemplares;
 private int NroPatrimonio;
 
  public Livro() {

    }

    public Livro(String titulo, int numPaginas, String editora, String ISBN, Cd CD, int ano, String autor,
            int nroExemplares, int nroPatrimonio, int CodBarra, String Categoria, boolean reservado) {

        setNumPaginas(numPaginas);
        setEditora(editora);
        setISBN(ISBN);
        setCD(CD);
        setReservado(reservado);
        setTitulo(titulo);
        setAno(ano);
        setAutor(autor);
        setCategoria(Categoria);
        setCdBarra(CodBarra);
        this.NroExemplares = nroExemplares;
        this.NroPatrimonio = nroPatrimonio;
    }

    public String getAsCSVLine() {
        return this.getNumPaginas() + ","
                + this.getEditora() + ","
                + this.getISBN() + ","
                + this.getCD() + ","
                + this.getTitulo() + ","
                + this.getAno() + ","
                + this.getAutor() + ","
                + this.getCategoria() + ","
                + this.getCdBarra() + ","
                + this.getReservado();
    }

     @Override
    public String toString(){
        
       return "Título: " + getTitulo() + ", " + 
              "Autor: " + getAutor() + ", " + 
              "Nº Páginas: " + getNumPaginas() + ", " + 
              "Editora: " + getEditora() + ", " + 
              "Categoria: " + getCategoria() + ", " + 
              "Ano: " + getAno() + ", " + 
              "Cód. Barra: " + getCdBarra() + ", " + 
              "ISBN:" +  getISBN() + ", " + 
              "Nº Exemplares: " + getNroExemplares() + ", " + 
              "Nº Patrimônio: " + getNroPatrimonio() + ", " + 
              "Cd: " + getCD();
                
    }

 
    public int getNumPaginas() {
        return numPaginas;
    }

    public void setNumPaginas(int numeroPaginas) {
        this.numPaginas = numeroPaginas;
    }

    public String getEditora() {
        return editora;
    }

    public void setEditora(String editora) {
        this.editora = editora;
    }


    public Cd getCD() {
        return cd;
    }

    public void setCD(Cd CD) {
        this.cd = CD;
    }
    
     public int getNroExemplares() {
        return NroExemplares;
    }

    public void setNroExemplares(int NroExemplares) {
        this.NroExemplares = NroExemplares;
    }

    public int getNroPatrimonio() {
        return NroPatrimonio;
    }

    public void setNroPatrimonio(int NroPatrimonio) {
        this.NroPatrimonio = NroPatrimonio;
    }

    public String getISBN() {
        return ISBN;
    }

    public void setISBN(String ISBN) {
        this.ISBN = ISBN;
    }
}

