package biblioteca;

import java.beans.XMLDecoder;
import java.beans.XMLEncoder;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;

//import testearquivo.Livro;

public class ObraDAO {
    
    public void salvarObras(ArrayList<Obra> exemplar) {
        FileOutputStream fout = null;
        try {
            fout = new FileOutputStream("/local/home/tads/NetBeansProjects/Biblioteca/Obra.xml");
            BufferedOutputStream bos = new BufferedOutputStream(fout);
            XMLEncoder xmlEncoder = new XMLEncoder(bos);
            xmlEncoder.writeObject(exemplar);
            xmlEncoder.close();
        } catch (Exception ex) {
            System.out.println("Erro: " + ex.getMessage());
        }
    }

    public ArrayList<Obra> carregarObras() {
        ArrayList<Obra> exemplar = new ArrayList();
        try {
            FileInputStream fis = new FileInputStream("/local/home/tads/NetBeansProjects/Biblioteca/Obra.xml");
            BufferedInputStream bis = new BufferedInputStream(fis);
            XMLDecoder xmlDecoder = new XMLDecoder(bis);
            exemplar = (ArrayList<Obra>) xmlDecoder.readObject();
        } catch (Exception e) {
            System.out.println("erro ao ler");
        } 
        return exemplar;
    }
    
    public void gravarUmaObra(Obra obra){
       ArrayList<Obra> listaObras = new ArrayList();
       listaObras = carregarObras();
       listaObras.add(obra);
       salvarObras(listaObras);
    }
    
}
 

