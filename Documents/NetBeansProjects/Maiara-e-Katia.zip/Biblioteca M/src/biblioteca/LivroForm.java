/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
// if (nomeDoLivroParaPesquisar.equals(li.getTitulo()))
package biblioteca;

import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author maiara
 */
public class LivroForm extends javax.swing.JFrame {

    /**
     * Creates new form LivroForm
     */
    public LivroForm() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        edTitulo = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        edAno = new javax.swing.JTextField();
        edNrExemplar = new javax.swing.JTextField();
        edEditora = new javax.swing.JTextField();
        edNrPatrimonio = new javax.swing.JTextField();
        edCategoria = new javax.swing.JTextField();
        btnGravar = new javax.swing.JToggleButton();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        edNrPaginas = new javax.swing.JTextField();
        btnLimparCampos = new javax.swing.JToggleButton();
        btnExcluir = new javax.swing.JToggleButton();
        edAutor = new javax.swing.JTextField();
        btnPesquisar = new javax.swing.JButton();
        edCodigoDeBarra = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        edISBN = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        edVoltar = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        CodBarraCD = new javax.swing.JTextField();
        PesquisarCD = new javax.swing.JButton();
        edTituloCD = new javax.swing.JTextField();
        btnAlterar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        edTitulo.setName("edTitulo"); // NOI18N

        jLabel1.setText("Título");

        jLabel2.setText("Ano");

        jLabel3.setText("Autor");

        jLabel4.setText("Num. exemplar");

        jLabel5.setText("Num. patrimônio");

        jLabel6.setText("Categoria");

        edAno.setName("edAno"); // NOI18N

        edNrExemplar.setName("edNumExemplares"); // NOI18N

        edEditora.setName("edEditora"); // NOI18N

        edNrPatrimonio.setName("edPatrimonio"); // NOI18N

        edCategoria.setName("edCategoria"); // NOI18N

        btnGravar.setText("Gravar");
        btnGravar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGravarActionPerformed(evt);
            }
        });

        jLabel8.setText("Num. Páginas");

        jLabel9.setText("Editora");

        edNrPaginas.setName("edNumPgs"); // NOI18N

        btnLimparCampos.setText("Limpar");
        btnLimparCampos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimparCamposActionPerformed(evt);
            }
        });

        btnExcluir.setText("Excluir");
        btnExcluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExcluirActionPerformed(evt);
            }
        });

        edAutor.setName("edAutor"); // NOI18N

        btnPesquisar.setText("Pesquisar");
        btnPesquisar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPesquisarActionPerformed(evt);
            }
        });

        jLabel10.setText("Cód. de barra");
        jLabel10.setToolTipText("");

        jLabel11.setText("ISBN");

        edVoltar.setText("Voltar");
        edVoltar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                edVoltarActionPerformed(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel7.setText("CADASTRO DE LIVRO");

        jLabel12.setText("CD(cód. Barras)");

        PesquisarCD.setText("Pesquisar CD");
        PesquisarCD.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PesquisarCDActionPerformed(evt);
            }
        });

        edTituloCD.setEnabled(false);

        btnAlterar.setText("Alterar");
        btnAlterar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAlterarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel7)
                .addGap(153, 153, 153))
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel10)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(edCodigoDeBarra, javax.swing.GroupLayout.PREFERRED_SIZE, 305, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 10, Short.MAX_VALUE)
                        .addComponent(btnPesquisar))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel3)
                            .addComponent(jLabel1)
                            .addComponent(jLabel9)
                            .addComponent(jLabel2)
                            .addComponent(jLabel6)
                            .addComponent(jLabel11))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(edCategoria, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(edAno)
                                    .addComponent(edISBN))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(edNrExemplar, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(edNrPatrimonio, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(edNrPaginas, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE))))
                            .addComponent(edEditora)
                            .addComponent(edTitulo)
                            .addComponent(edAutor)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(55, 55, 55)
                        .addComponent(btnGravar, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnAlterar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btnLimparCampos, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnExcluir, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(edVoltar, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jLabel8)
                                .addComponent(jLabel5)
                                .addComponent(jLabel4))))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel12)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(CodBarraCD, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(edTituloCD)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(PesquisarCD)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(8, 8, 8)
                .addComponent(jLabel7)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(edCodigoDeBarra, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnPesquisar)
                    .addComponent(jLabel10))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(edTitulo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(7, 7, 7)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(edAutor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(edEditora, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(9, 9, 9)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(edNrExemplar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(edCategoria, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel6)
                                .addComponent(jLabel5))
                            .addComponent(edNrPatrimonio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(8, 8, 8)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(edNrPaginas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel8)
                            .addComponent(edISBN, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel11)))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel2)
                        .addComponent(edAno, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel4)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel12)
                    .addComponent(CodBarraCD, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(PesquisarCD)
                    .addComponent(edTituloCD, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 29, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnGravar)
                    .addComponent(btnLimparCampos)
                    .addComponent(btnExcluir)
                    .addComponent(edVoltar)
                    .addComponent(btnAlterar))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnPesquisarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPesquisarActionPerformed
        try {
            Obra obra = new Obra();
            obra = obra.TemObra(Integer.valueOf(edCodigoDeBarra.getText()));

            if (obra != null && obra instanceof Livro) {

                edTitulo.setText(obra.getTitulo());
                edNrPaginas.setText(String.valueOf(((Livro) obra).getNumPaginas()));
                edEditora.setText(((Livro) obra).getEditora());
                edISBN.setText(((Livro) obra).getISBN());
                edAno.setText(String.valueOf(obra.getAno()));
                edAutor.setText(obra.getAutor());
                edNrExemplar.setText(String.valueOf(((Livro) obra).getNroExemplares()));
                edNrPatrimonio.setText(String.valueOf(((Livro) obra).getNroPatrimonio()));
                edCategoria.setText(obra.getCategoria());

            } else {
                JOptionPane.showMessageDialog(null, "Código não encontrado, cadastre um novo! ");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro ao Pesquisar livro: " + e.getMessage());
        }
    }//GEN-LAST:event_btnPesquisarActionPerformed

    private void btnExcluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExcluirActionPerformed
        Livro livro = new Livro();

        if (livro.excluirObra(edCodigoDeBarra.getText())) {
            JOptionPane.showMessageDialog(null, "Exemplar excluído com sucesso!");
            limparCampos();
        } else {
            JOptionPane.showMessageDialog(null, "Livro não encontrado!");
        }
    }//GEN-LAST:event_btnExcluirActionPerformed

    private void btnGravarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGravarActionPerformed
        try {
            Livro l = new Livro();

            if (l.verificarCdBarra(edCodigoDeBarra.getText())) {
                JOptionPane.showMessageDialog(null, "Código de barras já cadastrado, informar outro!");
            } else {
                gravaLivro();
                limparCampos();
                JOptionPane.showMessageDialog(null, "Gravado com sucesso!");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro ao gravar livro: " + e.getMessage());
        }
    }//GEN-LAST:event_btnGravarActionPerformed

    private void btnLimparCamposActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimparCamposActionPerformed
        limparCampos();
    }//GEN-LAST:event_btnLimparCamposActionPerformed

    private void edVoltarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_edVoltarActionPerformed
        this.dispose();
    }//GEN-LAST:event_edVoltarActionPerformed

    private void PesquisarCDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PesquisarCDActionPerformed
        try {
            Obra obra = new Obra();
            obra = obra.TemObra(Integer.valueOf(CodBarraCD.getText()));

            if (obra != null) {
                edTituloCD.setText(obra.getTitulo());
            } else {
                edTituloCD.setText("");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro ao pesquisar CD: " + e.getMessage());
        }
    }//GEN-LAST:event_PesquisarCDActionPerformed

    private void btnAlterarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAlterarActionPerformed
        Livro livro = new Livro();
        boolean alterado = livro.excluirObra(edCodigoDeBarra.getText());

        if (!alterado) {
            JOptionPane.showMessageDialog(null, "Livro não encontrada");
        } else {
            gravaLivro();
            limparCampos();
            JOptionPane.showMessageDialog(null, "Alterado com sucesso");
        }
    }//GEN-LAST:event_btnAlterarActionPerformed

    public void gravaLivro() {
        Livro livro = new Livro();
        Obra obra = new Obra();

        Cd cd = new Cd();
        if (!CodBarraCD.getText().equals("")) {
            cd = (Cd) obra.TemObra(Integer.valueOf(CodBarraCD.getText()));
        } else {
            cd = null;
        }

        Livro novoLivro = new Livro(
                edTitulo.getText(),
                Integer.valueOf(edNrPaginas.getText()),
                edEditora.getText(),
                edISBN.getText(),
                cd,
                Integer.valueOf(edAno.getText()),
                edAutor.getText(),
                Integer.valueOf(edNrExemplar.getText()),
                Integer.valueOf(edNrPatrimonio.getText()),
                Integer.valueOf(edCodigoDeBarra.getText()),
                edCategoria.getText(),
                false
        );
        ObraDAO obraDAO = new ObraDAO();
        obraDAO.gravarUmaObra(novoLivro);
    }

    public void limparCampos() {
        edTitulo.setText("");
        edNrPaginas.setText("");
        edEditora.setText("");
        edISBN.setText("");
        edAno.setText("");
        edAutor.setText("");
        edNrExemplar.setText("");
        edNrPatrimonio.setText("");
        edCategoria.setText("");
        edCodigoDeBarra.setText("");
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(LivroForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(LivroForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(LivroForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(LivroForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new LivroForm().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField CodBarraCD;
    private javax.swing.JButton PesquisarCD;
    private javax.swing.JButton btnAlterar;
    private javax.swing.JToggleButton btnExcluir;
    private javax.swing.JToggleButton btnGravar;
    private javax.swing.JToggleButton btnLimparCampos;
    private javax.swing.JButton btnPesquisar;
    private javax.swing.JTextField edAno;
    private javax.swing.JTextField edAutor;
    private javax.swing.JTextField edCategoria;
    private javax.swing.JTextField edCodigoDeBarra;
    private javax.swing.JTextField edEditora;
    private javax.swing.JTextField edISBN;
    private javax.swing.JTextField edNrExemplar;
    private javax.swing.JTextField edNrPaginas;
    private javax.swing.JTextField edNrPatrimonio;
    private javax.swing.JTextField edTitulo;
    private javax.swing.JTextField edTituloCD;
    private javax.swing.JButton edVoltar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    // End of variables declaration//GEN-END:variables
}
