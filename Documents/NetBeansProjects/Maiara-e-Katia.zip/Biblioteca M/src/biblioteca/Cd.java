package biblioteca;

public class Cd extends Obra{
  private float duracao; 

  public Cd(){
      
  }
  
  public Cd(String titulo, int ano, String autor, String categoria, float duracao, int cdBarra){

      setTitulo(titulo);
      setAno(ano);
      setAutor(autor);
      setCategoria(categoria);
      this.duracao = duracao;
      setCdBarra(cdBarra);
      
  }
  
   public String getAsCSVLine() {

      return    this.getTitulo() + ","
              + this.getAno() + ","
              + this.getAutor() + ","
              + this.getCategoria() + ","
              + this.getDuracao() + ","
              + this.getCdBarra()+ ","
              + this.getReservado();
                      
   }
   
   @Override
    public String toString() {

        return "Título Cd: " + getTitulo() + ", " +
               "Autor Cd: " + getAutor()  + ", " +
               "Categoria Cd: " + getCategoria() + ", " +
               "Ano Cd: " + getAno() + ", " +
               "Duração: " + getDuracao() + ", " +
               "Cód. Barra Cd: " + getCdBarra() + ", " +
               "Cd Reservado?: " + getReservado();
               
    }
    
    public float getDuracao() {
        return duracao;
    }

    public void setDuracao(float duracao) {
        this.duracao = duracao;
    }
}
