package biblioteca;

import java.beans.XMLDecoder;
import java.beans.XMLEncoder;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;

public class EmprestimoDAO {

    public void gravaUmEmprestimo(Emprestimo emp) {
            ArrayList<Emprestimo> listaEmprestimo = new ArrayList();
            listaEmprestimo = carregaEmprestimos();
            listaEmprestimo.add(emp);
            salvaEmprestimos(listaEmprestimo);
    }

    public void salvaEmprestimos(ArrayList<Emprestimo> listaDeClasse) {
        FileOutputStream fout = null;
        try {
            fout = new FileOutputStream("/local/home/tads/NetBeansProjects/Biblioteca/emprestimo.xml");
            BufferedOutputStream bos = new BufferedOutputStream(fout);
            XMLEncoder xmlEncoder = new XMLEncoder(bos);
            xmlEncoder.writeObject(listaDeClasse);
            xmlEncoder.close();
        } catch (Exception ex) {
            System.out.println("Erro: " + ex.getMessage());
        }
    }

    public ArrayList<Emprestimo> carregaEmprestimos() {
        ArrayList<Emprestimo> listaDeClasse = new ArrayList();
        try {
            FileInputStream fis = new FileInputStream("/local/home/tads/NetBeansProjects/Biblioteca/emprestimo.xml");
            BufferedInputStream bis = new BufferedInputStream(fis);
            XMLDecoder xmlDecoder = new XMLDecoder(bis);
            listaDeClasse = (ArrayList<Emprestimo>) xmlDecoder.readObject();
        } catch (Exception e) {
            System.out.println("erro ao ler");
        }
        return listaDeClasse;
    }

}
