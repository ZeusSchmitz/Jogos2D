package biblioteca;

import java.beans.XMLDecoder;
import java.beans.XMLEncoder;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;

public class PessoaDAO {
    
    public void salvarPessoas(ArrayList<Pessoa> pessoas) {
        FileOutputStream fout = null;
        try {
            fout = new FileOutputStream("/local/home/tads/NetBeansProjects/Biblioteca/Pessoa.xml");
            BufferedOutputStream bos = new BufferedOutputStream(fout);
            XMLEncoder xmlEncoder = new XMLEncoder(bos);
            xmlEncoder.writeObject(pessoas);
            xmlEncoder.close();
        } catch (Exception ex) {
            System.out.println("Erro: " + ex.getMessage());
        }
    }

    public ArrayList<Pessoa> carregarPessoas() {
        ArrayList<Pessoa> pessoas = new ArrayList();
        try {
            FileInputStream fis = new FileInputStream("/local/home/tads/NetBeansProjects/Biblioteca/Pessoa.xml");
            BufferedInputStream bis = new BufferedInputStream(fis);
            XMLDecoder xmlDecoder = new XMLDecoder(bis);
            pessoas = (ArrayList<Pessoa>) xmlDecoder.readObject();
        } catch (Exception e) {
            System.out.println("erro ao ler");
        } 
        return pessoas;
    }
    
     public void gravarUmaPessoa(Pessoa pessoa){
       ArrayList<Pessoa> listaPessoas = new ArrayList();
       listaPessoas = carregarPessoas();
       listaPessoas.add(pessoa);
       salvarPessoas(listaPessoas);
    }
}