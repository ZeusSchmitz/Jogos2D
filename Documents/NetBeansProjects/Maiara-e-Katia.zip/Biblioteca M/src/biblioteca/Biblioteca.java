package biblioteca;

public class Biblioteca {

    public static void main(String[] args) {
        BibliotecaForm BibliForm = new BibliotecaForm();
        BibliForm.setVisible(true);  
    }
    
}
