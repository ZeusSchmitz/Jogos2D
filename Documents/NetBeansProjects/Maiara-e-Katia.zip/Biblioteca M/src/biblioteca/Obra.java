package biblioteca;

import java.util.ArrayList;
import javax.swing.JOptionPane;

public class Obra {

    private String titulo;
    private int ano;
    private String autor;
    private String categoria; //(Classificação)
    private boolean reservado;
    private int cdBarra;

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public int getAno() {
        return ano;
    }

    public void setAno(int ano) {
        this.ano = ano;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String Categoria) {
        this.categoria = Categoria;
    }

    /**
     * @return the reservado
     */
    public boolean getReservado() {
        return reservado;
    }

    /**
     * @param reservado the reservado to set
     */
    public void setReservado(boolean reservado) {
        this.reservado = reservado;
    }
    
    public int getCdBarra() {
        return cdBarra;
    }

    public void setCdBarra(int cdBarra) {
        this.cdBarra = cdBarra;
    }

    public Obra TemObra(String TituloObra) {
        ObraDAO obraDAO = new ObraDAO();
        ArrayList<Obra> acervo = new ArrayList();
        acervo = obraDAO.carregarObras();

        for (Obra ob : acervo) {
            if (ob.getTitulo().equals(TituloObra)) {
                return ob;
            }
        }
        return null;
    }
    
    public Obra TemObra(int CodBarra) {
        ObraDAO obraDAO = new ObraDAO();
        ArrayList<Obra> acervo = new ArrayList();
        acervo = obraDAO.carregarObras();

        for (Obra ob : acervo) {
            if (ob.getCdBarra() == CodBarra) {
                return ob;
            }
        }
        return null;
    }
    

    public boolean excluirObra(String codigoBarra) {
        boolean excluiuObra = false;
        ObraDAO obraDAO = new ObraDAO();
        ArrayList<Obra> colecao = new ArrayList();
        colecao = obraDAO.carregarObras();

        for (Obra ob : colecao) {

            if ((Integer.valueOf(codigoBarra) == ob.getCdBarra())) {
                
                colecao.remove(ob);
                excluiuObra = true;
                break;
                
            }
        }
        obraDAO.salvarObras(colecao);
        return excluiuObra;
    }

    public boolean verificarCdBarra(String codigoBarra){
        boolean cdBarraExiste = false;
        ObraDAO obraDAO = new ObraDAO();
        ArrayList<Obra> colecao = new ArrayList();
        colecao = obraDAO.carregarObras();
        

        for(Obra obra : colecao){
           
            if((Integer.valueOf(codigoBarra) == (obra.getCdBarra()))){
                cdBarraExiste = true;
               // JOptionPane.showMessageDialog(null, "Código de barras já cadastrado, informar outro!");
                break;
            }
        }

        return cdBarraExiste;
    }

}
