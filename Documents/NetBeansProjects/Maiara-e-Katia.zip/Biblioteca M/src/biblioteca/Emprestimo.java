package biblioteca;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import javax.swing.JOptionPane;

public class Emprestimo {

    private Obra obra;
    private Pessoa pessoa;
    private Date PrevisaoDataDevolucao;

    public Emprestimo() {

    }

    public Emprestimo(Obra obra, Pessoa pessoa, Date PrevisaoDataDevolucao) {
        this.obra = obra;
        this.pessoa = pessoa;
        this.PrevisaoDataDevolucao = PrevisaoDataDevolucao;
    }

    public String getAsCSVLine() {
        return this.getObra() + ","
                + this.getPessoa() + ","
                + this.PrevisaoDataDevolucao + ",";
    }
    
        @Override
    public String toString(){   
        SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
        Date dataDev = getPrevisaoDataDevolucao();
        String data = formato.format(dataDev);
        
        return "Pessoa: " + getPessoa() + ", " +
               "Data Devolução: " + data + ", " + 
               "Detalhes da Obra: " + this.getObra();

                
    }

    public Obra getObra() {
        return obra;
    }

    public void setObra(Obra obra) {
        this.obra = obra;
    }

    public Pessoa getPessoa() {
        return pessoa;
    }

    public void setPessoa(Pessoa pessoa) {
        this.pessoa = pessoa;
    }

    public Date getPrevisaoDataDevolucao() {

        return PrevisaoDataDevolucao;
    }

    public void setPrevisaoDataDevolucao(Date PrevisaoDataDevolucao) {
        this.PrevisaoDataDevolucao = PrevisaoDataDevolucao;
    }

    public String calcularDataDevolucao(boolean pessoaEhServidor) {
        Date d = new Date();
        Calendar cal = Calendar.getInstance();
        cal.setTime(d); // Objeto Date() do usuário

        if (pessoaEhServidor) {
            cal.add(cal.DAY_OF_MONTH, +30);
        } else {
            cal.add(cal.DAY_OF_MONTH, +14);
        }

        this.PrevisaoDataDevolucao = cal.getTime();

        SimpleDateFormat format_ = new SimpleDateFormat("dd/MM/yyyy");
        String dataFormatada_ = format_.format(cal.getTime().getTime());

        return dataFormatada_;
    }

    public int calculaMulta(Date dataDevolucao) throws ParseException {
        Date dataHoje = new java.util.Date();
        int dias;

        dias = (int) ((dataHoje.getTime() - dataDevolucao.getTime()) / 86400000L);
        return dias;
    }

    public boolean excluirEmprestimo(int CPFPessoa, int cdBarra) {
        boolean excluiuEmprestimo = false;
        EmprestimoDAO empDAO = new EmprestimoDAO();
        ArrayList<Emprestimo> emprestimos = new ArrayList();
        emprestimos = empDAO.carregaEmprestimos();

        for (Emprestimo emp : emprestimos) {
            if (CPFPessoa == emp.getPessoa().getCPF()) {
                if (emp.getObra().getCdBarra() == cdBarra) {
                    emprestimos.remove(emp);
                    excluiuEmprestimo = true;
                    break;
                }
            }
        }
        empDAO.salvaEmprestimos(emprestimos);
        return excluiuEmprestimo;
    }

    public Emprestimo TemEmprestimo(int CPFPessoa, String nomeObra) {
        EmprestimoDAO emprestimoDAO = new EmprestimoDAO();
        ArrayList<Emprestimo> emprestimos = new ArrayList();
        emprestimos = emprestimoDAO.carregaEmprestimos();
        for (Emprestimo em : emprestimos) {
            if ((em.getPessoa().getCPF() == CPFPessoa) && (em.getObra().getTitulo().equals(nomeObra))) {
                return em;
            }
        }
        return null;
    }

    public void Emprestar(int CPFPessoa, String tituloObra, String DataDevolucao) {
        try {
            Emprestimo emp = new Emprestimo();
            Pessoa p = new Pessoa();
            Obra ob = new Obra();
            String erro = "";
            EmprestimoDAO emprestimoDAO = new EmprestimoDAO();
            ArrayList emprestimosExistentes = new ArrayList();
            emprestimosExistentes = emprestimoDAO.carregaEmprestimos();
            //Verifica se existe a pessoa informada
            p = p.TemPessoa(CPFPessoa);
            if (p == null) {
                erro = "| Pessoa não encontrada";

            } else {
                emp.setPessoa(p);
            }
            //Verifica se existe o livro informado
            ob = ob.TemObra(tituloObra);
            if (ob == null) {
                erro = "| Obra não encontrada";
            /*} else if ((VerificaLivroEmprestado(ob) == null) && emprestimosExistentes.size() != 0) {
                erro = "| Nenhuma obra disponível. É necessário reservar!";*/
            } else {
                emp.setObra(ob);
            }
            //falta ver se tem obra disponível para o empréstimo
            //Aqui entra se tudo der certo, pode reservar
            if (erro != "") {
                JOptionPane.showMessageDialog(null, erro);
            } else {
                SimpleDateFormat format_ = new SimpleDateFormat("dd/MM/yyyy");
                emp.setPrevisaoDataDevolucao(format_.parse(DataDevolucao));

                emprestimoDAO.gravaUmEmprestimo(emp);

                JOptionPane.showMessageDialog(null, "Empréstimo realizado com sucesso!");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro ao esprestar livro: " + e.getMessage());
        }
    }

    public void Renovar(int CPFPessoa, String tituloObra) {
        String erro = "";
        Emprestimo em = new Emprestimo();
        EmprestimoDAO emprestimoDAO = new EmprestimoDAO();
        em = TemEmprestimo(CPFPessoa, tituloObra);
        if (em != null) {
            if (em.getObra().getReservado() == false) {
                //aqui começa se deu tudo certo
                if (excluirEmprestimo(em.getPessoa().getCPF(), em.getObra().getCdBarra())) {
                    String DataDevolucao = em.calcularDataDevolucao(em.getPessoa().isEhServidor());
                    Emprestimo emp = new Emprestimo(em.getObra(),
                            em.getPessoa(),
                            em.getPrevisaoDataDevolucao());
                    emprestimoDAO.gravaUmEmprestimo(emp);
                }
            } else {
                erro = "Obra reservada! Impossível Renovar. Realize a devolução";
            }
        } else {
            erro = "\n Obra não emprestada para renovar! Empreste o livro para o usuário primeiro";
        }
        if (erro == "") {
            JOptionPane.showMessageDialog(null, "Obra renovada com sucesso!");
        } else {
            JOptionPane.showMessageDialog(null, erro);
        }
    }

    private void VerificarReserva(String tituloObra, int CPFPessoa) {
        //Carrega lista de emprestimo para pesquisa
        EmprestimoDAO empDAO = new EmprestimoDAO();
        ArrayList<Emprestimo> listaEmprestimos = new ArrayList();
        listaEmprestimos = empDAO.carregaEmprestimos();

        //Carrega lista de Obras para pesquisa
        ObraDAO obraDAO = new ObraDAO();
        ArrayList<Obra> listaObra = new ArrayList();
        listaObra = obraDAO.carregarObras();

        //Carrega lista de Pessoas para pesuisa
        PessoaDAO pessDAO = new PessoaDAO();
        ArrayList<Pessoa> listaPessoas = new ArrayList();
        listaPessoas = pessDAO.carregarPessoas();

        //Esta lista vai ser usada para descarregar todos as obras daquele título que estão emprestadas
        //Vou percorrer a lista de empréstimos e salvar as obras daquele titulo emprestadas
        ArrayList<Obra> listaDeExemplaresDoLivro = new ArrayList();
        for (Emprestimo pesquisaEmprestimo : listaEmprestimos) {
            if (pesquisaEmprestimo.getObra().getTitulo().equals(tituloObra)) {
                listaDeExemplaresDoLivro.add(pesquisaEmprestimo.getObra());
            }
        }
        boolean achou = false;
        //Testar se existe livro sem estar reservado ou emprestado para a pessoa pegar
        for (Obra pesquisaObras : listaObra) {
            if (pesquisaObras.getTitulo().equals(tituloObra)) {
                for (Obra obrasNalistaDeEmprestimo : listaDeExemplaresDoLivro) {
                    if (pesquisaObras.getCdBarra() == obrasNalistaDeEmprestimo.getCdBarra()) {
                        achou = true;
                    }
                }
                if (!achou) {
                    JOptionPane.showMessageDialog(null, "Biblioteca possui exemplar dessa obra disponível para emprestar! Não é necessário realizar reserva");
                    break;
                }
            }
        }
    }

    public void Reservar(String tituloObra, int CPFPessoa, boolean reserva/*ArrayList<Obra> listaExemplaresDoLivro ArrayList<Obra> listaObras, int CPFPessoa, String tituloObra*/) {
        if (reserva) {
            VerificarReserva(tituloObra, CPFPessoa);
        }

        ObraDAO obraDAO = new ObraDAO();
        Obra ob = new Obra();
        ArrayList<Obra> listaObra = new ArrayList();
        listaObra = obraDAO.carregarObras();

        ArrayList<Obra> listaExemplaresDoLivro = new ArrayList();
        for (Obra pesquisaObra : listaObra) {
            if (pesquisaObra.getTitulo().equals(tituloObra)) {
                listaExemplaresDoLivro.add(pesquisaObra);
            }
        }

        for (Obra obra : listaExemplaresDoLivro) {
            if (obra instanceof Livro) {
                Livro livro = new Livro(((Livro) obra).getTitulo(),
                        ((Livro) obra).getNumPaginas(),
                        ((Livro) obra).getEditora(),
                        ((Livro) obra).getISBN(),
                        ((Livro) obra).getCD(),
                                 obra.getAno(),
                                 obra.getAutor(),
                        ((Livro) obra).getNroExemplares(),
                        ((Livro) obra).getNroPatrimonio(),
                                 obra.getCdBarra(),
                                 obra.getCategoria(),
                                 reserva);
                listaObra.add(livro);
            } else {
                Cd cd = new Cd(obra.getTitulo(),
                               obra.getAno(),
                               obra.getAutor(),
                               obra.getCategoria(),
                         ((Cd) obra).getDuracao(),
                               obra.getCdBarra());
                listaObra.add(cd);
            }
        }
        obraDAO.salvarObras(listaObra);

        ArrayList<Obra> NovalistaObra = new ArrayList();

        NovalistaObra = obraDAO.carregarObras();

        for (Obra obra : NovalistaObra) {
            if (obra.getTitulo().equals(tituloObra) && obra.getReservado() != reserva) {
                NovalistaObra.remove(obra);
            }
        }
        obraDAO.salvarObras(NovalistaObra);
        if (reserva) {
            JOptionPane.showMessageDialog(null, "Livro reservado com sucesso");
        }
    }

    public void Devolver(int CPFPessoa, String tituloObra, String dataDevolucao) {
        Obra obra = new Obra();

        try {
            int multa = 0;
            Emprestimo emp = new Emprestimo();
            emp = TemEmprestimo(CPFPessoa, tituloObra);
            if (emp != null) {
                obra = obra.TemObra(emp.getObra().getTitulo());
                if (obra.getReservado()) {
                    Reservar(obra.getTitulo(), 0, false);
                }
                excluirEmprestimo(CPFPessoa, emp.getObra().getCdBarra());
                Pessoa p = new Pessoa();
                p = p.TemPessoa(CPFPessoa);
                if (p != null) {
                    SimpleDateFormat format_ = new SimpleDateFormat("dd/MM/yyyy");
                    if (emp.calculaMulta(format_.parse(dataDevolucao)) > 0) {
                        multa = emp.calculaMulta(format_.parse(dataDevolucao));
                    }
                    //Carrega lista de Pessoas para pesquisa
                    PessoaDAO pessDAO = new PessoaDAO();
                    ArrayList<Pessoa> listaPessoas = new ArrayList();
                    listaPessoas = pessDAO.carregarPessoas();
                    Pessoa pessoa = new Pessoa(p.getNome(),
                            p.getDataNascimento(),
                            p.getCPF(),
                            p.isEhServidor(),
                            multa
                    );
                    listaPessoas.add(pessoa);
                    pessDAO.salvarPessoas(listaPessoas);

                } else {
                    JOptionPane.showMessageDialog(null, "Pessoa não encontrada");
                }
                p.excluirPessoa(Integer.valueOf(CPFPessoa));

            } else {
                JOptionPane.showMessageDialog(null, "Empréstimo não encontrado");
            }
            JOptionPane.showMessageDialog(null, "Devolução realizada com sucesso!");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro" + e.getMessage());
        }
    }

    public Obra VerificaLivroEmprestado(Obra obra) {

        EmprestimoDAO empDAO = new EmprestimoDAO();
        ObraDAO obraDAO = new ObraDAO();
        ArrayList<Obra> obras = new ArrayList();
        obras = obraDAO.carregarObras();
        ArrayList<Emprestimo> emprestimos = new ArrayList();
        emprestimos = empDAO.carregaEmprestimos();
        boolean achouEmprestimo = false;

        for (Emprestimo e : emprestimos) {
            //verificar se o array de emprestimos contém o titulo que quer emprestar
            if (obra.getTitulo().equalsIgnoreCase(e.getObra().getTitulo())) {
                for (Obra ob : obras) {
                    //Pesquisar pelo código de barras, 
                    //ao encontrar um código que não foi emprestado ainda retornar a obra desse codigo de barras
                    if ((obra.getCdBarra() != ob.getCdBarra()) && (obra.getTitulo().equalsIgnoreCase(ob.getTitulo()))) {
                        return ob;

                    }
                }
            }
        }
        //se não encontrar um livro disponível retornar null
        return null;
    }

}
