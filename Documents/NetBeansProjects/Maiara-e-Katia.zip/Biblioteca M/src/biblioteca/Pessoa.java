package biblioteca;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import javax.swing.JOptionPane;

public class Pessoa {

    private String nome;
    private Date dataNascimento;
    private boolean ehServidor;
    private int CPF;
    private int multa;

    public Pessoa() {

    }

    public Pessoa(String nome, Date dtNasc, int CPF, boolean ehServidor, int multa) {

        this.nome = nome;
        this.dataNascimento = dtNasc;
        this.CPF = CPF;
        this.ehServidor = ehServidor;
        this.multa = multa;
    }

    public String getAsCSVLine() {

        return this.getNome() + ","
                + this.getDataNascimento() + ","
                + this.getCPF() + ","
                + this.getMulta() + ","
                + this.isEhServidor();
    }

    @Override
    public String toString() {

        SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
        Date dataNasc = getDataNascimento();
        String data = formato.format(dataNasc);

        return "Nome: " + getNome() + ", "
                + "CPF: " + String.valueOf(getCPF()) + ","
                + "Data nasc.: " + data + ", "
                + "Multa: " + String.valueOf(getMulta());

    }

    public boolean excluirPessoa(int CPF) {
        boolean excluiuPessoa = false;
        PessoaDAO pessoaDAO = new PessoaDAO();
        ArrayList<Pessoa> pessoas = new ArrayList();
        pessoas = pessoaDAO.carregarPessoas();

        for (Pessoa p : pessoas) {

            if ((Integer.valueOf(CPF) == p.getCPF())) {
                pessoas.remove(p);
                excluiuPessoa = true;
                break;
            }
        }

        pessoaDAO.salvarPessoas(pessoas);
        return excluiuPessoa;
    }

    //MÃ©todo responsÃ¡vel por conferir se existe uma pessoa. Se existir retorna a pessoa, se nÃ£o existir, retorna null    
    public Pessoa TemPessoa(int CPFPessoa) {
        PessoaDAO pessoaDAO = new PessoaDAO();
        ArrayList<Pessoa> grupo = new ArrayList();
        grupo = pessoaDAO.carregarPessoas();

        for (Pessoa p : grupo) {

            if (CPFPessoa == p.getCPF()) {
                return p;
                //emp.setPessoa(p); 
            }
        }
        return null;
    }

    public boolean verificarCPF(String cpf) {
        boolean achou = false;
        PessoaDAO pessoaDAO = new PessoaDAO();
        ArrayList<Pessoa> pessoas = new ArrayList();
        pessoas = pessoaDAO.carregarPessoas();

        for (Pessoa p : pessoas) {

            if ((Integer.valueOf(cpf) == (p.getCPF()))) {
                achou = true;
                //JOptionPane.showMessageDialog(null, "CPF já cadastrado!");
                break;
            }
        }

        return achou;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Date getDataNascimento() {
        return dataNascimento;
    }

    public void setDataNascimento(Date dataNascimento) {
        this.dataNascimento = dataNascimento;
    }

    public boolean isEhServidor() {
        return ehServidor;
    }

    public void setEhServidor(boolean ehServidor) {
        this.ehServidor = ehServidor;
    }

    public int getCPF() {
        return CPF;
    }

    public void setCPF(int CPF) {
        this.CPF = CPF;
    }

    public int getMulta() {
        return multa;
    }

    public void setMulta(int multa) {
        this.multa = multa;
    }
}
