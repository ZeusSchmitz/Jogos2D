package exercicio4;

public class TestaPista {
    
    public static void main(String[] args) {

        Pista p = new Pista();
        // cria dois carros
        p.insereCarro(new Carro("G", "MDD 1020", "Gol", 15, 10, 10));
        p.insereCarro(new Carro("U", "MKP 3713", "Uno", 16, 7, 13));

        while (!p.algumCarroPercorreuAPista()) {
            p.movimentaCarrosUmSegundo();
            //System.out.println(p.mostraSituacaoDosCarros());
            System.out.println(p.desenhaPista());
        }

        // qual carro ganhou? Pode ser que dois carros empataram?
        System.out.println(p.retornaNomesDosCarrosQuePercorreramAPista());
    }
}
