package exercicio4;

public class Carro {
    private String modelo;
    private int rendimento;  // km/L
    private float capacidade;  // litros
    private int tempoVelMax; // segundos
    private String placa; 
    private String ID; //identificador pra desenhar na pista
    
    private int velocidade = 0;
    private float tanque = 0;
    private float hodometro = 0;
    
    // se o carro parar, considera-se um novo inicio de movimento    
    private int tempoDecorridoAposIniciarMovimento = 0; 
    
    // tempo TOTAL
    private int tempoTotalDePercurso = 0;
    
    // valor a ser informado, obtido da pista, para poder calcular 
    // aceleracao do carro
    int velocidadeMaximaPermitida = 100; // km/h    ]
    
    // os carros iniciam com o tanque cheio
    private boolean abastecendo = false;
    
    // ha quanto tempo estah abastecendo?
    int tempoAbastecendo = 0;
    
    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public int getRendimento() {
        return rendimento;
    }

    public void setRendimento(int rendimento) {
        this.rendimento = rendimento;
    }

    public float getCapacidade() {
        return capacidade;
    }

    public void setCapacidade(int capacidade) {
        this.capacidade = capacidade;
    }

    public int getTempoVelMax() {
        return tempoVelMax;
    }

    public void setTempoVelMax(int tempoVelMax) {
        this.tempoVelMax = tempoVelMax;
    }
    
    public int getVelocidade() {
        return velocidade;
    }

    public void setVelocidade(int velocidade) {
        this.velocidade = velocidade;
    }

    public float getTanque() {
        return tanque;
    }

    public void setTanque(float tanque) {
        this.tanque = tanque;
    }
    
    public float getHodometro() {
        return hodometro;
    }

    public void setHodometro(float hodometro) {
        this.hodometro = hodometro;
    }

    public int getTempoDecorridoDesdePartida() {
        return tempoDecorridoAposIniciarMovimento;
    }

    public void setTempoDecorridoAposIniciarMovimento(
            int tempoDecorridoDesdePartida) {
        this.tempoDecorridoAposIniciarMovimento = tempoDecorridoDesdePartida;
    }

    public boolean alcancouVelocidadeMaxima() {
        return this.tempoDecorridoAposIniciarMovimento >= this.tempoVelMax;
    }
    
    public float calculaIncrementoDeVelocidade() {
        return velocidadeMaximaPermitida / tempoVelMax;
    }
    
    public void andaUmSegundo() {
        
        // ainda nao alcancou a velocidade maxima?
        if (!this.alcancouVelocidadeMaxima()) {
            // vamos acelerar o quanto eh possivel em uma unidade de tempo
            velocidade += this.calculaIncrementoDeVelocidade();
        }
     
        // quantos km consigo andar no momento?
        float deslocamento = (float) velocidade / 3600;
        
        // incrementa o hodometro
        hodometro += deslocamento;
        
        // tira do tanque o combustivel necessario para percorrer o trecho
        tanque -= (float) deslocamento / rendimento;
        
        // aumentar tempo de viagem
        tempoDecorridoAposIniciarMovimento++; 
        
        // aumentar tempo total
        tempoTotalDePercurso++;
        
    }

    float getAutonomia() {
        if (this.abastecendo) {
            return 0;
        }
        if (this.alcancouVelocidadeMaxima()) {
            return this.velocidadeMaximaPermitida * this.tanque;
        } else {
            float tmpTanque = this.tanque;
            int tmpVelocidade = this.velocidade;
            float tmpHodometro = this.hodometro;
            // simulacao de aceleracao ateh chega na velocidade maxima
            for (int i = this.tempoDecorridoAposIniciarMovimento; 
                    i < tempoVelMax; i++) {
                // dah pra andar?
                if (tmpTanque > 0) {
                    tmpVelocidade += this.calculaIncrementoDeVelocidade();
                    tmpHodometro += tmpVelocidade / 3600;    
                }
            }
            //chegou na velocidade maxima. Ainda tem tanque?
            if (tmpTanque > 0) {
                // complementa a distancia, agora na velocidade maxima
                tmpHodometro += velocidadeMaximaPermitida * tmpTanque;
            }
            return tmpHodometro - this.hodometro;
        }
    }

    public boolean isAbastecendo() {
        return abastecendo;
    }

    public void setAbastecendo(boolean abastecendo) {
        this.abastecendo = abastecendo;
    }
    
    public void abastecaDuranteUmSegundo() {
        this.tempoAbastecendo++;
    }
    
    public Carro(String id, String placa, String modelo, int rendimento, 
            int capacidade, int tempoVelmax) {
        this.placa = placa;
        this.modelo = modelo;
        this.rendimento = rendimento;
        this.capacidade = capacidade;
        this.tempoVelMax = tempoVelmax;
        this.ID = id;
        
        // enche o tanque do carro, quando ele eh criado
        this.tanque = this.capacidade;
    }

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public int getTempoTotalDePercurso() {
        return tempoTotalDePercurso;
    }

    public void setTempoTotalDePercurso(int tempoTotalDePercurso) {
        this.tempoTotalDePercurso = tempoTotalDePercurso;
    }

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }
}
