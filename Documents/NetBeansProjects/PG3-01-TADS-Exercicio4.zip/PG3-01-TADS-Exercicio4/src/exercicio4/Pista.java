package exercicio4;

import java.util.ArrayList;

public class Pista {

    private int extensao = 200; // km
    private int dEP = 100; // distancia entre postos, em km
    private int tParada = 60; // tempo de reabastecimento, em segundos

    ArrayList<Carro> carros = new ArrayList<>();

    int distanciaEntrePostos = 100; // km

    public int getExtensao() {
        return extensao;
    }

    public void setExtensao(int extensao) {
        this.extensao = extensao;
    }

    public int getdEP() {
        return dEP;
    }

    public void setdEP(int dEP) {
        this.dEP = dEP;
    }

    public int gettParada() {
        return tParada;
    }

    public void settParada(int tParada) {
        this.tParada = tParada;
    }

    public void insereCarro(Carro c) {
        carros.add(c);
    }

    // faz os carros andarem em 1 segundo
    public void movimentaCarrosUmSegundo() {
        for (int i = 0; i < carros.size(); i++) {

            Carro c = carros.get(i);

            // distancia do carro ateh a chegada
            float quantoFaltaPraChegada = this.getExtensao()
                    - c.getHodometro();

            // faz o deslocamento do carro
            if (!c.isAbastecendo()) {
                c.andaUmSegundo();
            } else {
                c.abastecaDuranteUmSegundo();
                // passaram-se 2 minutos para o abastecimento?
                if (c.tempoAbastecendo == 60) {
                    //define tanque cheio
                    c.setTanque(c.getCapacidade());
                    // zera tempo de inicio apos movimento
                    c.setTempoDecorridoAposIniciarMovimento(0);
                    //libera o carro do abastecimento
                    c.setAbastecendo(false);
                }
            }

            // serah que dah pra andar ateh a chegada?
            boolean temAutonomiaPraConcluir = (c.getHodometro()
                    + c.getAutonomia()) >= quantoFaltaPraChegada;
            if (!temAutonomiaPraConcluir) {
                // se chegou em um posto de gasolina
                if ((c.getHodometro() % this.distanciaEntrePostos)
                        == 0) {
                    c.setAbastecendo(true);
                }
            }
        }
    }

    public boolean algumCarroPercorreuAPista() {
        for (Carro next : carros) {
            if (next.getHodometro() >= this.getExtensao()) {
                return true;
            }
        }
        return false;
    }

    public String retornaNomesDosCarrosQuePercorreramAPista() {
        String s = "";
        for (Carro next : carros) {
            if (next.getHodometro() >= this.getExtensao()) {
                s += "[" + next.getModelo() + " " + next.getPlaca()
                        + ", tempo=" + next.getHodometro() + "KM em "
                        + next.getTempoTotalDePercurso()
                        + " segundos]";
            }
        }
        return s;
    }

    public String mostraSituacaoDosCarros() {
        String s = "";
        for (Carro next : carros) {
            s += "[" + next.getModelo() + " " + next.getPlaca()
                    + ", KM=" + next.getHodometro() + ", t="
                    + next.getTempoTotalDePercurso() + "s, L="
                    + next.getTanque();
            if (next.isAbastecendo()) {
                s += " ABASTECENDO ";
            }
            s += "]";
        }
        return s;
    }

    public String desenhaPista() {

        // divide extensao por 80 colunas
        int cols = 80;
        
        // inicializa retorno geral
        String sG = "";
        
        // percorre cada carro
        for (Carro next : carros) {

            String s = "";
            
            // pega o valor inteiro dos kms percorridos
            int kmPercorrido = (int) next.getHodometro();
            
            // converte posicao do carro para numero de colunas
            int colsPercorridas = (kmPercorrido * cols) / this.extensao;
            
            // acrescenta "+" ao caminho que jah passou
            for (int i = 0; i < colsPercorridas; i++) {
                s += "+";
            }
            // desenha o ID do carro
            s += next.getID();
            
            // desenha o caminho que falta
            for (int i = colsPercorridas+1; i < cols; i++) {
                s += "-";
            }
            
            sG += s + "\n";
        }
        return sG;
    }
}
