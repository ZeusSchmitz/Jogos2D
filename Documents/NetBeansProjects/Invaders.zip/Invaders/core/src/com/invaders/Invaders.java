package com.invaders;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input.Keys;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import java.util.ArrayList;
import java.util.Random;

public class Invaders extends Game {
    
    public static final int ALTURA = 600;
    public static final int LARGURA = 800;
    private static final int VELX = 10;
    private static final int VELY = 10;
    
    private SpriteBatch batch;
    private Texture blackarrow, blackshot;
    private Texture redarrow, redshot;
    
    private Objeto jogador;
    
    private float tempoDisparo = 0.0f, tempoDisparoInimigo = 0.0f;
    private int i, j;
    private Objeto disparo, inimigo;
    private final Random random = new Random();
    private final ArrayList<Objeto> disparosJogador = new ArrayList();
    private final ArrayList<Objeto> listaInimigos = new ArrayList();
    private final ArrayList<Objeto> disparosInimigos = new ArrayList();
    
    @Override
    public void create() {
        batch = new SpriteBatch();
        blackarrow = new Texture("blackarrow.png");
        blackshot = new Texture("blackshot.png");
        redarrow = new Texture("redarrow.png");
        redshot = new Texture("redshot.png");

        jogador = new Objeto(blackarrow, 10, ALTURA / 2 - blackarrow.getHeight() / 2, VELX, VELY);
        inicializaInimigos();
    }
    
    private void inicializaInimigos() {
        int x = LARGURA - redshot.getWidth() - 10;
        int y = 0;
        for (int i = 1; i <= 9; i++) {
            Objeto inimigo = new Objeto(redarrow, x, y, VELX, VELY);

            listaInimigos.add(inimigo);
            y += redarrow.getHeight() + 3;
        }
    }
    
    private void efetuaDisparoJogador() {
        disparosJogador.add(jogador.criaDisparo(blackshot));
    }
    
    @Override
    public void render() {
        tempoDisparo += Gdx.graphics.getDeltaTime();
        tempoDisparoInimigo += Gdx.graphics.getDeltaTime();
        
        // 1) movimentação do jogador....
        //W = subir (y++), S = descer (y--)
        if (Gdx.input.isKeyPressed(Keys.W)) {
            jogador.movimentaAcima();
        }
        if (Gdx.input.isKeyPressed(Keys.S)) {
            jogador.movimentaAbaixo();
        }
        
        i = 0;
        while (i < disparosJogador.size()) {
            disparo = disparosJogador.get(i);
            disparo.movimentaDireita();
            if (disparo.getX() > LARGURA) {
                disparosJogador.remove(i);
            } else {
                j = 0;
                boolean atingiuInimigo = false;
                while (j < listaInimigos.size()) {
                    inimigo = listaInimigos.get(j);
                    if (disparo.colide(inimigo)) {
                        atingiuInimigo = true;
                        listaInimigos.remove(j);
                        break;
                    }
                    j++;
                }
                
                if (atingiuInimigo) {
                    disparosJogador.remove(i);
                } else {
                    i++;
                }
            }
        }
        
        // 3) verificando se o jogador disparou para criar
        //    o objeto que representa o disparo realizado.
        if (Gdx.input.isKeyPressed(Keys.SPACE)) {
            if (tempoDisparo >= 1.0f) {
                tempoDisparo = 0.0f;
                efetuaDisparoJogador();
            }
        }
        
        // 4) efetua o deslocamento dos disparos dos inimigos e
        // verifica se saíram da tela ou colidiram com o jogador
        // para remover do jogo...
        j = 0;
        while (j < disparosInimigos.size()) {
            Objeto disparo = disparosInimigos.get(j);
            disparo.movimentaEsquerda();
            if (disparo.getX() < 0) {
                disparosInimigos.remove(j);
            } else if (disparo.colide(jogador)) {
                Gdx.app.exit();
            } else {
                j++;
            }
        }
        
        // 5) efetua os disparos dos inimigos. a cada chamada
        // do método render() um inimigo aleatório fará um disparo.
        if (tempoDisparoInimigo > 0.5f) {
            tempoDisparoInimigo = 0.0f;
            if (listaInimigos.size() > 0) {
                j = random.nextInt(listaInimigos.size());
                disparosInimigos.add(listaInimigos.get(j).criaDisparo(redshot));
            }
        }
        
        Gdx.gl.glClearColor(1, 1, 1, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        
        batch.begin();
        
        // desenha o jogador..
        jogador.desenha(batch);
        
        //desenha todos os disparos realizados pelo jogador...
        for (Objeto objeto : disparosJogador) {
            objeto.desenha(batch);
        }
        
        // desenha todos os inimigos que ainda estão no jogo...
        for (Objeto inimigo : listaInimigos) {
            inimigo.desenha(batch);
        }
        
        // desenha os disparos realizados pelos inimigos...
        for (Objeto disparoInimigo : disparosInimigos) {
            disparoInimigo.desenha(batch);
        }
        
        batch.end();
    }
    
    @Override
    public void dispose() {
        batch.dispose();
        blackarrow.dispose();
        blackshot.dispose();
        redarrow.dispose();
        redshot.dispose();
    }
}